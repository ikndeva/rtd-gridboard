# coding: utf_8
# btest1.py
# 画盤モジュールのテスト
import sys
from argparse import ArgumentParser
import random
import vector as vec 
import common as com 
import board as bd

verbose = True

#画像の解像度をppi (pixel per inch)で設定する
#myppi = 1024
#myppi = 572

#=====
#便利関数
#=====
def pos(xy): 
    return vec.geom_trans_gen(xy, 
                func=lambda p: vec.point_apply(p, 
                        lambda orig:(orig * edgelen)))

##=====
## コマンドライン引数
##=====
CMD_NAME = (__file__.split('/'))[-1]

def reading_args_and_options():
    USAGE_STR = f'Usage: python3 { CMD_NAME } OPTIONS '
    ap = ArgumentParser(usage=USAGE_STR)
    ## 
    # ap.add_argument('args', type=str,
    #                 ##note: デフォールトはpositional argなのでdestは不要
    #                 help='sequence of numbers')
    ## options: 
    ## boundingbox
    ap.add_argument('-b', '--boundingbox', action='store_true', default=False, 
                    help='show verbose messages')
    ## ppi 
    ap.add_argument('-p', '--ppi', type=int, default=144, 
                    help='set resolution parameter ppi (pixel-per-inch)')
    ## shape 
    ap.add_argument('-s', '--shape', type=str, default=None, 
                    help='set the shape to int:int')
    ## width 
    ap.add_argument('-w', '--width', type=int, default=1, 
                    help='set the width of a line')
    ## shape 
    ap.add_argument('-o', '--outline_kind', type=str, default=None, 
                    help="set the type of outlines in ('r', 'rect', 'l', 'line')")
    ## verbose 
    ap.add_argument('-v', '--verbose', action='store_true', default=False, 
                    help='show verbose messages')
    ## 
    args = ap.parse_args()
    return args, ap

def normalize_shape(shape_str):
    shape0 = shape_str.split(':')
    com.ensure(len(shape0)==2, 'shape={mn} must have two numbers!')
    shape = [0,0]
    for i in range(2):
        shape[i] = int(shape0[i])
    return shape
    

##======
## メイン文
##======
ratio = 16
# ratio = 2.0
def pos(xy):
    def app(p):
        return vec.point_apply(p, lambda x: (x * ratio))
    return vec.geom_trans_gen(xy, 
                              func=lambda p: app(p))

# def pos(xy): 
#     return vec.geom_trans_gen(xy, 
#                 func=lambda p: vec.point_apply(p, 
#                         lambda orig:(orig * edgelen)))

#色
#色
fancy = ['lightskyblue', 'mediumaquamarine',
         'lightpink',
         #'greenyellow',
         'tan', 
         'lightgrey']
# fancy = ['lightskyblue', 'mediumaquamarine', 'greenyellow', 'lightgrey']
# fancy = ['lightskyblue', 'palegoldenrod', 'lightseagreen', 'lightgrey']
solid = ['red', 'darkorchid', 'lightcoral', 'orange', 'royalblue', ]

#ランダム色
def random_color(color_list):
    idx = int(len(color_list) * random.random())
    return color_list[idx % len(color_list)]

def next_color(color_list, col):
    idx1 = color_list.index(col) + 1
    return color_list[idx1 % len(color_list)]

def get_xy(point=None, width=1.0): 
    q = point; q1 = vec.add(q, (width,width))
    xy = [q, q1]
    return xy 


if __name__ == '__main__':
    #parameters
    verbose=False
    fontsize = 12
    edgelen=2*fontsize
    shape_pt = None
    
    #コマンドラインの引数とオプションの読み込み
    opt, ap = reading_args_and_options()
    if opt.width: width1=max(1, opt.width)
    else: width1=max(1, int(edgelen/12.0))

    #set shape
    shape = [3, 3] #default 
    if opt.shape:
        shape = normalize_shape(shape_str) 
    m, n = shape
    id = 0

    grid_len_pt = 1
    if opt.ppi: 
        grid_len_pt = opt.ppi


    id  = 0

    # 位置指定による2D配置のテスト
    #xy = [(0, 0), (1,1)]
    
    #======
    #画像枠の生成
    #======
    pi = bd.Canvas(ppi=opt.ppi, 
                   #shape_pt=shape_pt, 
                   fontsize_regular_pt=fontsize,
                   grid_len_pt=grid_len_pt, 
                   verbose=False)

    #適当に背景色をとる
    #bg = fancy[id % len(fancy)]
    bg0 = random_color(fancy)
    b0 = pi.margin_board(margin=0.25, 
                         background=bg0)

    #次に異なる背景色をとる
    bg1 = random_color(fancy)
    while bg1==bg0: 
        bg1 = random_color(fancy)
    #bg = next_color(fancy, bg)
    b1 = b0.margin_board(margin=0.25, 
                         background=bg1)
    #======
    ##長方形を書く
    #======
    xy = get_xy(point=(id, id % 2), width=1.0)
    #fg = solid[col % len(solid)]
    fg = random_color(solid)
    b1.rectangle(xy=xy, fill=fg, verbose=False)
    id += 1; 

    xy = get_xy(point=(id, id % 2), width=1.0)
    #fg = solid[col % len(solid)]
    fg = random_color(solid)
    b1.rectangle(xy=xy, fill=fg, verbose=False)
    id += 1; 

    xy = get_xy(point=(id, id % 2), width=1.0)
    #fg = solid[col % len(solid)]
    fg = random_color(solid)
    b1.rectangle(xy=xy, fill=fg, verbose=False)
    id += 1; 

    #======
    #描画
    #======
    pi.show(verbose=True)

    #debug
    sys.exit(0)
    

#============
#描画
#============
pi.show(verbose=True)

##EOF


