#anchor.py
# anchor notation
# - アンカー記法は，文字列 ac in {l,m,r}x{a,m,b}である．
# - 例： 'la', 'lb', 'mm', 'rb', ...
# - アンカー記法は，単位正方形`[0,1]x[0,1]`中の点anchor.point(ac)を表す．
import math 
import vector as vec 
import common as com

X_ANCHOR = { 'l':0.0, 'm':0.5, 'r':1.0 }
Y_ANCHOR = { 'a':0.0, 'm':0.5, 'b':1.0 }
X_AXIS = 0
Y_AXIS = 1

#アンカーの型検査：アンカー文字列
def is_anchor_symbol(anc, axis):
    """ancが，指定した軸の正しいアンカー文字列かを判定し，真偽値を返す.

    - アンカー記法は，長さ2の文字列 ac in {l,m,r} x {a,m,b}である．例： 'la', 'lb', 'mm', 'rb', ... 
    
    - アンカー記法は，単位正方形`[0,1]x[0,1]`中の点anchor.point(ac)を表す．

    Args: 

    	anc (str): アンカー文字列の候補

    	axis (int): 軸を表す整数 X_AXIS = 0, Y_AXIS = 1 のどれか

    Returns: 
    	bool: True or False 
    """
    if not (type(anc) is str and len(anc) == 1):
        return false
    else:
        if axis==X_AXIS: 
            return (anc in X_ANCHOR)
        elif axis==Y_AXIS: 
            return (anc in Y_ANCHOR)
        else: 
            panic(f'wrong axis={axis}')

#型検査：アンカー対            
def is_anchor_str(apair):
    """apairが，指定した軸の正しいアンカー対かを判定し，真偽値を返す.

    Args: 
    apair (str): 
      アンカー文字列の候補
    axis (int): 
      軸を表す整数 X_AXIS = 0, Y_AXIS = 1 のどれか

    Returns: 
      bool: True or False 
    """
    if not type(apair) is str:
        return False
    elif len(apair)!=2:
        return False
    else: 
        return (is_anchor_symbol(apair[0], X_AXIS) and is_anchor_symbol(apair[1], Y_AXIS))

#=====
# アンカー操作の関数
#=====

#アンカー点
def make_point(ac, verbose=False):
    """アンカー文字列acを受け取り，それが表すアンカー点`p in [0,1]^2`を返す．
    """
    com.ensure(is_anchor_str(ac), 'ac={ac} must be an anchor string!')
    return (X_ANCHOR[ac[0]], Y_ANCHOR[ac[1]])

#アンカー点
def make_anchor_point(anchor=None, xy=None, verbose=False):
    """長方形領域xyから，anchorの表す点に対応する点を返す．
    xy : a point or a rectangular region
    """
    if vec.is_point(xy):
        origin = (0,0)
        shape = xy
    elif vec.is_rect(xy):
        origin = xy[0]
        shape = vec.sub(xy[1], xy[0])
    ratio = make_point(anchor, verbose=verbose)
    return vec.add(origin, vec.scale(rect, ratio))

#obsolute 
def anchor_sides(ac, verbose=False):
    """アンカー文字列 ac を受け取り，対応するブール値 below, left を返す．

    Returns: 
    	pair(bool): ブール値の対 below, left

    - below == True (False) <-> アンカーが水平線より下側（上側）にあるとき
    - left  == True (False) <-> アンカーが垂直線より左側（右側）にあるとき
    """
    ensure(is_anchor_str(ac), 'ac={ac} is not an anchor')
    left  = (X_ANCHOR[ac[0]] < 0.5)
    below = (Y_ANCHOR[ac[1]] < 0.5)
    return below, left

# def anchor_sides(anchor, verbose=False):
#     """
#     アンカー文字列を受け取り，対応するブール値 below, left を返す．
#     below == True (False) <-> アンカーが水平線より下側（上側）にあるとき
#     left  == True (False) <-> アンカーが垂直線より左側（右側）にあるとき
#     """
#     x, y = anchor_vec(anchor, verbose=verbose)
#     below, left = False, False
#     if y<0: below=True
#     if x>0: left=True
#     return below, left

### 接線ベクトルの角度を求める。
def get_angle(p):
    """線分の方向ベクトルpから、その角度をラジアンで求める．

    Args: 
    	p (vec): 方向ベクトル
    """
    rad_tan, len = vec.coord_polar(p)  ## rad_tan:接線ベクトル
    rad_tan = vec.normalize_rad(rad_tan) ## rad in [0,2*pi)
    return rad_tan

EPS_DEGREE=5  ## 水平・垂直判定の誤差範囲定数
def get_anchor(p, anchor_hint=None):
    """方向に関するアンカーヒントを元に，アンカー文字列を返す．

    Args: 
    	p (vec): 中心点のベクトル

    	anchor_hint (str): "lrab"の任意の文字からなる任意長の文字列．省略された場合は任意に選ぶ． (None)

    Returns: 
    	str: アンカー文字列．長さ2の文字列 ac in {l,m,r} x {a,m,b}. 
    """
    # anchor_hintから，タイブレーク用のフラグ(left, below)を求める
    below = left = False
    if type(anchor_hint) is str and anchor_hint and len(anchor_hint) > 0:
        for c in anchor_hint: 
            if c=='l':
                left = True
            elif c=='r':
                left = False
            elif c=='a':
                below = True
            elif c=='b':
                below = False
        pass

    # 区切りを設定する
    eps = math.pi * (EPS_DEGREE/180.0)
    rad0 = eps
    rad1 = 0.5*math.pi - eps
    rad2 = 0.5*math.pi + eps
    rad3 = math.pi - eps

    #
    rad_tan = get_angle(p)
    if rad_tan > math.pi:
        rad_tan -= math.pi
    
    if rad_tan >= 0 and rad_tan < rad0: ## horizontal: r or l
        if below: anchor = 'ma'
        else:     anchor = 'mb'
    elif rad_tan >= rad0  and rad_tan < rad1: ## upper-right -- lower-left
        if below: anchor = 'ra'
        else:     anchor = 'lb'
    elif rad_tan >= rad1 and rad_tan < rad2: ## vertical 
        if left: anchor = 'rm'
        else:    anchor = 'lm'
    elif rad_tan >= rad2 and rad_tan < rad3: ## upper-left -- lower-right
        if below: anchor = 'la'
        else:     anchor = 'rb'
    elif rad_tan >= rad3 and rad_tan <= math.pi:
        if below: anchor = 'ma'
        else:     anchor = 'mb'
    else: 
        com.panic(f'rad_tan must be in [0, pi): rad_tan={ rad_tan }')
    return anchor 

def anchor_vec(anchor, verbose=False):
    """アンカー文字列"xy"を受け取り、 それが表す8近傍 {-1,0,+1}^2の単位方向ベクトルを返す。

    Args: 
    	anchor (str): アンカー文字列

    Returns: 
    	vec: 単位方向ベクトル anc_vec in {-1,0,+1}^2. 

    """
    if len(anchor) != 2:
        com.panic(f'anchor must have length two! anc={ anchor }')
    ha, va = anchor[0], anchor[1]
    if verbose:
        print(f'anchor_vec: anchor={anchor} ha={ha} va={va}')
    x, y = 0, 0
    ## horizontal 
    if   ha=='l': x = +1
    elif ha=='m': x = 0
    elif ha=='r': x = -1
    ## vertical
    if   va=='a' or va=='t': y = +1
    elif va=='m': y = 0
    elif va=='b' or va=='s' or va=='d': y = -1
    ## normal
    norm = math.sqrt(x*x + y*y)
    if norm != 0: 
        anc_vec = (x/norm, y/norm)
    else:
        anc_vec = (x,y)
    return anc_vec

def anchor_select(p, anchor=None, below=False, left=False):
    """線分の単位接線ベクトルpに直交するアンカーベクトルを計算する．    

    - ここに，線分p の単位法線ベクトルをアンカーベクトルと呼ぶ．
    - アンカーベクトルは，preference (below, left)の向きに整合する向きを選ぶ

    Args: 
    	p (vec): 単位接線ベクトル p = (x,y)

    	anchor (str): アンカー文字列 hv

    	below (bool): 下向きに整合させるか. False

    	left (bool): 左向きに整合させるか. False

    Returns: 
    	vec: 単位法線ベクトル（アンカーベクトル）vec_normal

    内部変数

    - anchor: pの法線ベクトルの8近傍文字列表現 in {l,m,r}x{a,m,b}={-1,0,+1}^2
    - vec_normal: pの単位法線ベクトルの直交座標表現
    - rad_tan   : pの単位接線ベクトルの方向角（x軸を0）
    - rad_normal: pの単位法線ベクトルの方向角（x軸を0）
    """
    ##
    below, left = False, False  ##デフォールトのアンカー側
    if anchor: 
        below, left = anchor_sides(anchor)

    ##方向
    ## vec_normal: labelの移動方向の単位ベクトル
    ## note: downward in [0, pi),  upperward in (pi, 2*pi)
    ## since x-axis and y-axis are oriented to right and below in a board
    ## rad_normal = vec.normalize_rad(get_angle(p) + 0.5*math.pi) ## rad in [0,2*pi)
    vec_normal = vec.rotate_by_rad(vec.unit_vector(p), math.pi)
    # vec_normal = vec.unit_normal_vector(p)
    if not below:
        vec_normal = vec.scalar_mult(vec_normal, -1.0)  ##normalization
    return vec_normal
    # return vec_normal, rad_tan, rad_normal

def corner(xy, anchor, verbose=False):
    """矩形 xy と，その周上の位置指定のアンカー文字列"xy"を受け取り、 中心点からその位置を示す8近傍 {-1,0,+1}^2の単位方向ベクトルを返す。

    Args: 
    	xy (rect): 矩形

    	anchor (str): アンカー文字列

    Returns: 
    	vec: 単位方向ベクトル anc_vec in {-1,0,+1}^2. 

    """
    com.ensure(vec.is_point_seq(xy), f'xy={xy} must be a point list!')
    com.ensure((type(anchor) is str and len(anchor)==2), 'anchor={anchor} must be str of length 2!')
    ha, va = anchor[0], anchor[1]
    if verbose: print(f'anchor_vec: anchor={anchor} ha={ha} va={va}')
    x = y = 0.0 
    ## horizontal 
    if   ha=='l': x = xy[0][0]
    elif ha=='m': x = 0.5*(xy[0][0] + xy[1][0])
    elif ha=='r': x = xy[1][0]
    ## vertical
    if   va=='a': y = xy[0][1]
    elif va=='m': y = 0.5*(xy[0][1] + xy[1][1])
    elif va=='b': y = xy[1][1]
    return (x, y)

def corner_pair(xy, ac_pair=None, verbose=False):
    """矩形 xy と，アンカー文字列の対 ac_pairを受け取り、アンカーベクトルの対を返す．

    Args: 
    	xy (rect): 矩形

    	ac_pair (pair(str)): アンカー文字列の対 (ac0, ac1)

    Returns: 
    	pair(vec): 8近傍単位方向ベクトルの対(p0, p1) in ({-1,0,+1}^2)^2. 

    """
    com.ensure((type(ac_pair) is tuple and len(ac_pair)==2 and
                is_anchor_str(ac_pair[0]) and is_anchor_str(ac_pair[1])),
               'ac_pair must be a pair of length-2 strings')
    p0 = corner(xy, ac_pair[0], verbose=verbose)
    p1 = corner(xy, ac_pair[1], verbose=verbose)
    return [p0, p1]
    

