#!/usr/bin/env python3 
# coding: utf_8
# grid.drawtree.py
"""多分木の描画のモジュール．
""" 
import sys
import random
import math 
import common as com
import vector as vec 
import gridboard as gp 

#parameters
verbose=True
debug=False
STEM_STR='..'

DEFAULT_NODE_SHAPE=(0.2, 0.2)

debug_margin=False
def dprint(dep, msg):
    print('..'*dep, end='')
    print(f'{msg}')

def rootxy(geom):
    """親座標系におけるノードの配置オブジェクトgeomの根の位置を返す．
    """
    p = vec.add(geom.xy, geom.rootxy)
    return p 

#check path
if debug: 
    print(f'sys.path: { sys.path }')

##======
## 多分木
##======

class Node:
    """多分木のノードのクラス．
    """
    def __init__(self, label=None, invisible=False):
        self.label=label
        self.children = []
        self.invisible = invisible

    def isLeaf(self):
        """葉かどうかを返す．

        Returns: 
            bool: 葉ならばTrue, 内部ノードならばFalseを返す．
        """
        return self.children==None or len(self.children) == 0

    def append(self, child):
        """与えられたノードを，自身の子として追加する．

        Args: 
            child (Node): 子として追加するノード

        Returns: 
            なし
        """
        self.children.append(child)

    def add_child(self, child):
        """与えられたノードを，自身の子として追加する．関数appendへのラッパー．

        Args: 
            child (Node): 子として追加するノード

        Returns: 
            なし
        """
        self.children.append(child)

##======
## ヘルパー関数
##======

## 前順巡回のノードのリストを返す。
def pre(node, L):
    """前順巡回のノードのリストを返す。
    """
    L.append(node)
    if node.children == None:
        return L
    for child in node.children: 
        pre(child, L)

## 項表現の文字列を返す。
def term_str(node):
    """ノードnodeの項表現文字列を返す。
    """
    s = ''
    s += f'{node.label}'
    if node.isLeaf():
        return s 
    t = ''
    for child in node.children: 
        if len(t) > 0:
            t += ' '
        t += term_str(child)
    if len(t) > 0:
        s += '(' + t + ')'
    return s

##======
## 木のTreeGeom
##======

class TreeGeom:
    """木のノードの配置用オブジェクト（TreeGeom）のクラス．

    Attributes: 
        node (Node): ノード
        label (str): ラベルの文字列
        parent (TreeGeom): 親ノード
        xy: 局所座標系の原点．デフォールト=(0,0)
    	lxy=(0,0): exp
        ratio (float): 拡大率．デフォールト=1.0
        margin (float): ノード周囲のマージン．デフォールト=0.0
        roffset (float): 配置のオフセット．デフォールト=1.0
        invisible (bool): 不可視にするフラグ．デフォールト=False

    以下は，内部で計算される．

        children (list(TreeGeom)): 子のリスト.
        rootxy: 根の座標．デフォールト=(0,0)
        shape: ノードの配置のサイズ．デフォールト=(0,0)

    * ノードオブジェクトとノードラベルのラッパーとして，ノードの座標と，局所座標系を保持する．
    * 子から親への変換の合成による再帰的な座標変換を実現している．
    """
    def __init__(self,
                 node=None,
                 label=None, 
                 parent=None, 
                 xy=(0,0),
                 lxy=(0,0), #exp
                 ratio=1.0,
                 margin=0.0,
                 roffset=1.0,
                 invisible=False):
        ## 基本情報
        self.node=node #given
        self.label=label #given 
        self.parent=parent #given 
        self.children=[]
        ## geom
        self.xy=xy #given 
        self.lxy=lxy #given 
        self.ratio=ratio #given 
        self.rootxy=(0,0)
        self.shape=(0,0)
        self.invisible=invisible #不可視か？
        ### const
        pass

    def summary(self):
        return {
            'xy': f'{vec.fmt(self.xy, 1)}',
            'rootxy': f'{vec.fmt(self.rootxy, 1)}',
            'shape': self.shape
        }
    
    def po(self, p):
        """与えられた任意の点 p の座標変換を行って得られた点を返す．

        Args: 
        	p (point): 自身の局所座標系での任意の点

        Returns: 
        	point: 木の根がもつ大域的座標系に変換後の点q

        * 入力点pを自身の局所座標で変換して得られた点を，自分の親の座標系に再帰的に送り出して，全ての変換を合成して得られる点qを返す．

        """
        q = vec.add(vec.scalar_mult(p, self.ratio), self.xy)
        if self.parent:
            return self.parent.po(q)
        else:
            return q

    def add_child(self, child):
        """ノードchildを自分の子として追加する．
        """
        self.children.append(child)

    def to_str(self, depth=0, func=lambda geom_: f'{ geom_.summary() }'):
        """自身のTreeGeomの文字列表現を返す．
        """
        print(f'{STEM_STR * depth}{func(self)}')
        if self.children: 
            for child in self.children:
                child.to_str(depth=depth+1, func=func)

## root selection policy

## root selection policy
def root_by_mean(geom):
    """根の配置ポリシー関数．重心ポリシーに基づいて，自身の局所座標における根の位置の点(x,y)を返す．

    Args: 
    	geom (TreeGeom): ノードの配置オブジェクト

    Returns: 
    	vec2: 重心の子のx位置を表すベクター (x,y) = (x_mean, 0.0)

    * locate関数のfunc_root引数の値に用いる．
    * 根位置の決定方法： 重心位置ポリシー
    	+ x座標は，重心の子の中心点(x_mean, y_mean)のx座標x_meanである．
    	+ y座標は常に領域の上端を表すy=0である．

    """
    return (geom.shape[0]/2.0, 0)

## root selection policy
def root_by_median(geom):
    """
根の配置ポリシー関数．中央位置ポリシーに基づいて，自身の局所座標における根の位置の点(x,y)を返す．

    Args: 
    	geom (TreeGeom): ノードの配置オブジェクト

    Returns: 
    	vec2: 自身の局所座標における根の位置を表すベクター (x,y) = (x_median, 0.0)．

    * locate関数のfunc_root引数の値に用いる．
    * 二分木の描画では、外点を追加した上で、中央中心ポリシーを用いると見栄えが良い．

    * 根位置の決定方法： 中央位置ポリシー
    	+ x座標は，中央の子の中心点(x_median, y_median)のx座標x_medianである．
    	+ y座標は常に領域の上端を表すy=0である．
    """
    # select the median mid
    clen = len(geom.children)
    if clen == 0:
        ## 0個の子の場合        
        rx = geom.shape[0]/2.0
    elif clen % 2 == 1:
        ## 奇数個の子の場合
        ## - 中央の子をとり、その根の位置を返す
        mid = math.floor(clen/2)
        if mid < 0 or mid >= clen:
            com.panic(f'@error: index out of range: mid={mid}, clen={clen}')
        geom0 = geom.children[mid]
        rx = geom0.lxy[0] + geom0.rootxy[0]
    else:
        ## 偶数個の子の場合
        ## - 中央の二つの子をとり、その間の中央を返す
        mid = math.floor(clen/2)
        geom0 = geom.children[mid-1]
        geom1 = geom.children[mid]
        x0  = geom0.lxy[0] + geom0.shape[0]
        x1  = geom1.lxy[0]
        rx  = (x0 + x1) / 2.0 
    return (rx, 0)

## TreeGeom 
## 与えられた木から、各部分木をかこむ包含矩形を生成する。    
def locate(node,
           parent=None,
           xy=(0,0),
           lxy=(0,0), 
           roffset=1, margin=0, padding=0, 
           func_root=root_by_mean,
           depth=0,
           shape_node=DEFAULT_NODE_SHAPE,
           shrink=1.0,
           verbose=False,
           **kwargs):
    """
    kwargs: ratio=1.0, margin=0.0, roffset=1.0
    """
    if node == None:
        return
    ## process a node 
    geom = TreeGeom(node=node, parent=parent, xy=xy, lxy=lxy, label=node.label, invisible=node.invisible)
    if debug_margin:
        dprint(depth, f'@node: label={node.label}, xy=({xy[0]:.1f}, {xy[1]:.1f})')
    ## case: leaf
    if node.children == None or len(node.children) == 0:
        geom.shape = shape_node
        geom.rootxy= (shape_node[0]/2.0, 0)
        return geom
    ## case: branching node 
    else: 
        ## initialize metrics
        w1, d1, h1 = 0, roffset, 0
        idx = 0
        for child in node.children:
            if idx>0:
                w1 += margin 
            else: 
                w1 += padding
            geom1 = locate(node=child,
                           parent=node,
                           xy=(xy[0] + w1, xy[1] + d1),
                           lxy=(w1, d1),
                           # roffset, 
                           # margin=margin,
                           # padding=padding,
                           roffset=(roffset * shrink),
                           margin=(margin * shrink),
                           padding=(padding * shrink),
                           #
                           func_root=func_root,
                           depth=depth+1,
                           shape_node=shape_node,
                           shrink=shrink, 
                         **kwargs)
            geom.add_child(geom1)
            ## update metrics 
            w1 += geom1.shape[0]
            h1 = max(h1, roffset + geom1.shape[1])
            idx = idx + 1

        ## postprocessing metrics 
        if idx>0:
            w1 += padding
        h1 = h1 + padding ##always
        geom.shape = (w1, h1)
        geom.rootxy = func_root(geom)
    return geom

##======
## 木の描画関数
##======

## 木をgeomから描画する
def draw(geom, parent=None, bd=None,
         xy=(0,0), 
         fill='black', 
         fill_node=None, 
         fill_edge=None, 
         fill_label=None, 
         fill_bb=None,
         size='regular', anchor=None, label_margin=0, 
         verbose=False):
    """
    fill='black', fill_node=None, fill_edge=None, fill_label=None, fill_bb=None, 
    """
    # xy = geom.xy
    shift = (0.1, 0.1)

    kwargs = {
        'bd':bd, 'fill':fill, 'fill_node':fill_node, 'fill_edge':fill_edge, 'fill_label':fill_label, 'fill_bb':fill_bb, 'size':size, 'anchor':anchor, 'label_margin':label_margin
    }

    _shift_xy = lambda p: vec.add(p, xy)

    ##長方形geomを書く
    if fill_bb:
        xy_geom = map(_shift_xy, [geom.xy, vec.add(geom.xy, geom.shape)])
        # 包含長方形bbを描画
        bd.outline_rectangle(xy=xy_geom, outline=fill_bb, width=4)
        # 長方形の右上にshapeを描画
        xy_note_ = _shift_xy(vec.add(geom.xy, (geom.shape[0],0))) 
        bd.text(xy=xy_note_, text=f'({geom.shape[0]:.1f}, {geom.shape[1]:.1f})', fill=fill_bb, anchor='ra', size='scriptsize')

    ## 子で再帰
    if geom.children: 
        for geom1 in geom.children:
            draw(geom1, xy=xy, parent=geom, **kwargs)

    ## 不可視の場合は、ノードを描画しない
    if geom.invisible:
        return 
            
    ## 辺を描画
    if parent and fill_edge: 
        xy_edge = map(_shift_xy, [rootxy(parent), rootxy(geom)])
        bd.line(xy=xy_edge, fill=fill_edge)
        
    ## ノードを描画
    if fill_node:
        bd.dot(xy = _shift_xy(rootxy(geom)), width=4, fill=fill_node)
    
    ## ラベルを描画
    if fill_label:
        bd.text(xy = _shift_xy(rootxy(geom)), text=f'{ str(geom.label) }',
                fill=fill_label, anchor=anchor,
                size=size,
                label_margin=label_margin)
    return 


##=====
## サンプル描画関数
##=====

debug_make=False

def make_tree_figure(root,
                     roffset=0.5, 
                     margin=0.1, 
                     padding=0.05,
                     shrink=0.9, 
                     # shrink=1.0, 
                     fill='navy',
                     fill_node=None, 
                     fill_edge=None, 
                     fill_label=None, 
                     fill_bb=None,
                     # fill_node='black',
                     # fill_edge='darkslateblue',
                     # fill_label='firebrick',
                     # fill_bb='darksalmon',
                     #canvas and background
                     bgcolor_canvas='white', 
                     bgcolor='lightgrey',
                     #grid lines
                     fill_grid=None, 
                     width_grid=2,
                     #labels
                     size='regular',
                     anchor='la',
                     label_margin=4.0, 
                     verbose=False): 

    ## 木の描画情報を生成する
    kwargs_geom = {
        'roffset':roffset,
        'margin':margin,
        'padding':padding,
        'shrink':shrink, 
        'shape_node':(0.05,0.2), 
        'func_root':root_by_median,
    }
    geomroot = locate(root, **kwargs_geom)
    
    ## 基本の格子盤をおく
    shape_bd = vec.ceil(geomroot.shape)
    xy_board, shape_canvas = gp.wrap_canvas(shape_bd, margin=0.5, align='ma')
    im = gp.Canvas(gridwidth=240, shape=shape_canvas, bgcolor=bgcolor_canvas)

    ## 上にひとまわり小さな格子盤をおく
    board = gp.GridBoard(parent=im, xy=xy_board, shape=shape_bd, bgcolor=bgcolor)
    
    #width_grid = 2
    if fill_grid: 
        board.grid(invisible_hline=False,
                   invisible_vline=False,
                   fill=fill_grid, 
                   width=width_grid)
    
    if debug_make:
        print(f'debug:'
              +f'\n geomroot.shape={vec.fmt(geomroot.shape,1)}'
              +f'\n board.shape={vec.fmt(board.shape,1)}'
              +f'\n im.shape={vec.fmt(im.shape,1)}'
              +'')

    ## 木を画版に描画する
    kwargs_dw = {
        'fill':fill,
        'fill_node':fill_node, 
        'fill_edge':fill_edge, 
        'fill_bb':fill_bb, 
        'fill_label':fill_label, 
        'anchor':anchor, 
        'size':size, 
        'label_margin':label_margin, 
        'verbose':False
    }
    xy_geom = gp.align_xy(geomroot.shape, board.shape, align='mm')
    draw(geomroot, xy=xy_geom, bd=board, **kwargs_dw)
    return im

##=====
## ヘルパー関数
##=====

## 前順ノードIDと地理情報のリストを返す。
def enumerate(geom):
    L = []
    rec_enum(geom, idx_parent=-1, L=L)
    return L
              
def rec_enum(geom, idx_parent=None, L=[]):
    """
    fill='black', fill_node=None, fill_edge=None, fill_label=None, fill_bb=None, 
    """
    idx = len(L)
    node_xy = {
        'idx':idx,
        'idx_parent':idx_parent, 
        'xy':rootxy(geom),
        'label':geom.label
    }
    L.append( node_xy )

    ## 子で再帰
    if geom.children: 
        for geom1 in geom.children:
            rec_enum(geom1, idx_parent=idx, L=L)
    return 

##======
## メイン文
##======

if __name__ == '__main__':
    nums = []
    if len(sys.argv) >= 2:
        for i in range(1, len(sys.argv)): 
            nums.append(int(sys.argv[i]))
    else:
        com.panic('too few or may argments!'
              +f'usage: python3 { sys.argv[0] } num1 ... numN ')

# EOF

