#!/usr/bin/env python3 
# coding: utf_8
# pilimage.py
"""Pillowライブラリを用いた基底の画版のパッケージ

デフォールト値は次の通り

絶対サイズ

* DEFAULT_DISPLAY_SHAPE_PT = (640, 480) ．デフォールトの画像サイズ．

スタイルパラメータ（要設定．経験的）

* DEFAULT_PEN_WIDTH_PT=4．単位px
* DEFAULT_DOT_WIDTH_PT=8．単位px
* DEFAULT_CORNER_KIND = 'round'．矩形の角の形状．丸と四角など．
* DEFAULT_ARROW_SHAPE=(1,3)．矢印の頭の幅と長さの比率
* RATIO_ARROW_HEAD_WIDTH = 4．矢印幅が線の幅の何倍か

"""
import sys
import os 
sys.path.insert(0, os.path.abspath('../board'))
import numpy as np
import math
import common as com 
import kwargs as kw
import vector as vec 
import anchor as ac 
import pixel as px 
import pilfont

DEBUG_PATH=True

#if DEBUG_PATH:
    # com.log(f'debug:printing paths in module:{ __name__ }...')
    # for d in sys.path:
    #     com.log(f'  { d }')
    # com.log(f'debug:printed paths')

#Pillow package
import PIL as pil
from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont

DEBUG_OPS = False

#絶対サイズ
DEFAULT_DISPLAY_SHAPE_PT = (640, 480) #デフォールトの画像サイズ

#スタイルパラメータ
#要設定．経験的
DEFAULT_PEN_WIDTH_PT=4
DEFAULT_DOT_WIDTH_PT=8 #px
DEFAULT_CORNER_KIND = 'round'
DEFAULT_ARROW_SHAPE=(1,3)
RATIO_ARROW_HEAD_WIDTH = 4 ##矢印幅が線の幅の何倍か

debug_native=False

#note: length
#1inch = 2.54cm = 25.4mm
#1pt = 1/72inch
#実測：macbookpro13, retina, 2段大きめ:
# - 1px = 0.6299 pt => 120dpi
# - 1pt = 1.5875 = 1.6 px

#==========
#ヘルパー関数
#==========

def centered_box_shape(xy=None, width=None, anchor=None):
    """矩形 xy とその幅（直径）を与えて，矩形の重心にアンカーを設定して配置した新しい矩形xy1を返す．

    Args: 
    	xy (rect): 矩形

    	width (number): 幅

    	anchor (str): アンカー文字列．方向を表す長さ2の文字列 (see anchor.py)

    Returns: 
    	rect: 新しい矩形 xy1

    Examples: 
    	例::
    		kwargs1['xy'] = centered_box_shape(xy=xy, width=diam)
    """
    if anchor: 
        com.ensure(ac.is_anchor_str(anchor),
                   f'anchor={anchor} must be an anchor str!')
    else:
        anchor = 'mm'
    istep = ac.make_point(anchor)
    istep = (int(istep[0]), int(istep[1]))
    width = int(width)
    W = int(width-1)
    p = [0,0]
    q = [0,0]
    #x-axis
    if anchor[0]=='l':
        p[0], q[0] = xy[0], xy[0]+W
    elif anchor[0]=='m':
        p[0], q[0] = xy[0]-int(0.5*W), xy[0]+-int(0.5*W)
    elif anchor[0]=='r':
        p[0], q[0] = xy[0]-W, xy[0]
    else:
        com.panic(f'no anchor[0]={anchor[0]} is allowed in {0}-axis!')
    #y-axis
    if anchor[1]=='a':
        p[1], q[1] = xy[1], xy[1]+W
    elif anchor[1]=='m':
        p[1], q[1] = xy[1]-int(0.5*W), xy[1]+int(0.5*W)
    elif anchor[1]=='b':
        p[1], q[1] = xy[1]-W, xy[1]
    else: 
        com.panic(f'no anchor[1]={anchor[1]} is allowed in {1}-axis!')
    xy1 = px.normalize_xy([tuple(p), tuple(q)])
    if False:
        com.log(f'@debug:outline: orig:xy={xy} width={width} W={W} => new:rect={ xy1  }')
    return xy1


#離散化
def kwargs_round_px(kwargs=None, keys=None, verbose=False):
    """キーワード引数辞書において，指定したキーを離散化する（px）
    元の辞書に破壊的演算を行って，変更した辞書を返す．

    Examples: 

    	例．破壊的変更を行うので返り値はいらない::

    	    kwargs_round_px(kwargs1, ['xy', 'width'])
    """
    if keys==None:
        return kwargs
    for key in keys:
        if key in kwargs: 
            kwargs[key] = vec.round_px(kwargs[key]) #整数化
    return kwargs

#==========
#基盤画像系
#==========

# class PilImage(com.Loggable):
class PilImage(com.Loggable):
    count = 0  #count instance id 
    
    def __init__(self,
                 mode='rgb', #'rgb' for pdf, 'rgba' for png
                 ppi=None, #ppi = pixel_per_inch
                 shape_pt=None, 
                 fontbase=None,
                 fontsize_regular_pt=None, 
                 pen_width_pt=None,
                 bgcolor='white', #exp
                 dep_init=0, 
                 verbose=False):
        """実装レイヤーの画盤を生成するコンストラクタ．
        Parameters
        ----------
        mode: str
          画像フォーマット (pil.ImageDraw)
        shape_pt: int 
          画像の大きさ (in pt)
        fontbase: PillowFontBase
          PILフォントの辞書．指定しなければ，自動生成される．
        fontsize_regular_pt: int 
          標準フォントのサイズ (in pt)
        pen_width_pt: int or float 
          regularのペン幅 (in pt)
        verbose: 
          実行情報を表示する

        Returns 
        ----------

        Atributes
        ----------
        """
        #パラメータ
        self.mode = mode
        self.ppi  = ppi
        self.fontbase = fontbase ##キャッシュされたフォント辞書
        self.verbose = verbose
        self.bgcolor = bgcolor
        self.depth   = dep_init
        #インスタンスカウント
        self.id = PilImage.count;
        PilImage.count += 1

        if verbose:
            self.repo(msg=f'PilImage.__init__(): { vars(self) }')
        
        #解像度の設定
        if not self.ppi:
            self.ppi = pilfont.DEFAULT_PPI
        if verbose:
            self.repo(isChild=True, msg=f'@debug: self.ppi={self.ppi}, option ppi={ppi}')
        self.ppi_ratio = float(self.ppi)/float(com.POINT_PER_INCH) #1pt = 1/72 inch
        
        #内部パラメータ        
        # ペンの太さ
        if pen_width_pt: 
            self.pen_width_px = pen_width_pt * self.ppi_ratio
        else:
            self.pen_width_px = DEFAULT_PEN_WIDTH_PT * self.ppi_ratio

        # 画像サイズ in px
        if not shape_pt:
            shape_pt = DEFAULT_DISPLAY_SHAPE_PT
        self.shape_px = vec.round_px(vec.scale(shape_pt, self.ppi_ratio)) 
        #備考：PILではsizeパラメータは整数対でなければならない．
        if self.verbose:
            self.repo(isChild=True, msg=f'shape_pt={shape_pt}\tself.shape_px={self.shape_px}')
            # com.log(f'shape_pt={shape_pt}\nself.shape_px={self.shape_px}')

        # フォント辞書の生成
        if not self.fontbase:
            self.fontbase  = pilfont.PillowFontBase(ppi=self.ppi,
                                                    fontsize_regular_pt=fontsize_regular_pt)
        
        if self.verbose: 
            self.repo(isChild=True, msg=f'@pilimage.PilImage(): vars={vars(self)}')
        
        #画像の生成
        """画像領域を生成する"""
        self.im = pil.Image.new(self.mode,
                                self.shape_px,
                                self.bgcolor) ##画像基盤の生成
        self.drawer = pil.ImageDraw.Draw(self.im)  ##画像ハンドル
        return 
                
                
    # 基本：描画命令の転送
    # 
    def send_draw(self, cmd, kwargs, verbose=False):
        """基本：描画命令の転送を行う．

        Args: 
            cmd (str): 描画命令名の文字列

            kwargs (dict): 描画命令のキーワードパラメータからなる辞書．
            depth (int): 呼び出しの入れ子深さを表す非負整数．デバッグ用．

        Returns: 
        	なし

        描画命令は，Boardオブジェクトから転送されてくる対 (cmd, kwargs)として，扱う．

        現在，pillow上で，次の描画命令を実装している．

        * line: 直線を描く．
        * rectangle: 長方形を描く．
        * ellipse: 円と楕円を描く．
        * arc: 円弧を描く．
        * dot: 太丸を描く．
        * text: テキストを書く．
        * textbbox: テキストの包含矩形を求める．

        本pilimageクラスに，新しい描画演算を実装する際は，次のように行う．

        * 新しい描画演算を，pilimageクラスのメソッドfuncxxx(self, cmd, kwargs)として実装する．
        * この関数は，pillowのnative描画演算を用いて，pillowの描画オブジェクトへのハンドルself.drawerに直接書き込む形で実装する．
        * メソッドの引数は，関数名の文字列'cmdxxx'と，演算のキーワード引数の辞書**kwargsをとるものとする．
        * これを，本関数のディスパッチの条件分岐に，次のようにして追加する::

            if cmd=='line':
                return self.line(depth+1, **kwargs)
            ...
            elif cmd=='cmdxxx':
                return self.oprxxx(depth+1, **kwargs)
            ...
            else:
                panic(f'no such a cmd={cmd}!: kwargs={kwargs}')
        """
        if self.verbose:
            self.repo(f"PilImage.send_draw@@: cmd={cmd} kwargs={ kwargs }")

        # if not ('depth' in kwargs):
        #     kwargs['depth'] = depth+1
            
        #演算のdispatch
        com.ensure(type(cmd) is str, 'cmd={cmd} must be a string!')
        if cmd=='line':
            return self.line(**kwargs)
        elif cmd=='rectangle':
            return self.rectangle(**kwargs) 
        elif cmd=='ellipse':
            return self.ellipse(**kwargs)
        elif cmd=='arc':
            return self.arc(**kwargs)
        elif cmd=='dot':
            return self.dot(**kwargs)
        elif cmd=='text':
            return self.text(**kwargs)
        elif cmd=='textbbox':
            return self.textbbox(**kwargs)
        else:
            panic(f'no such a cmd={cmd}!: kwargs={kwargs}')
    
    def image(self): 
        """画像オブジェクトの返却"""
        if self.im == None: 
            com.panic('画像オブジェクトがNone!')
        return self.im
            
    def draw(self):
        """描画ハンドルを返す．

        * 描画ハンドル self.drawer は，pillowのnative 描画オブジェクトである．

        """
        if self.drawer == None:
            com.panic('画像オブジェクトがNone!')
        return self.drawer

    def show(self, noshow=False, verbose=False, depth=0):
        """画像を表示する．

        * 表示は，pillowの描画オブジェクトへのハンドルself.drawerに対して，pillowの描画命令 show()を呼び出すことで行われる．
        """
        if not noshow:
            self.im.show()
        else:
            if verbose: self.repo(f'.show()@@: @Warning: skipping show() for pil.Image object due to flag noshow={ noshow }')
        if verbose:
            self.repo(f'debug: PilImage.show(): done')
        return 
            
    ## 
    def save(self, imgfile=None, verbose=False):
        """画像をファイルに保存する．

        Args: 
            imgfile (str): 保存する画像ファイルの名前. 拡張子(pdf, png, jpg, ...)に応じて，自動的に適切なフォーマットで保存される．
        
            verbose (bool): ログ出力のフラグ．

        Returns: 
        	なし
        """
        if self.verbose:
            self.repo(f'saved to file: { imgfile }')
        self.im.save(imgfile)
        return

    # Boardのpt単位から，pilimageのpx単位へ長さを変換する

    
    # キーワード引数辞書からの部分コピー
    def extract_with_trans_px(self, kwargs=None, keys=None,
                              trans=None, verbose=False):
        """キーワード引数辞書から，新しい引数辞書を作成して返す．この際，
        - keysのキーはそのまま抽出.
        - transのキーはfuncで変換して抽出．
        """
        ### 内部関数：数値，点，点対を，pt単位px単位へ出る数値を長さ変換する
        def geom_trans_(num_or_xy, verbose=False):
            return vec.ex_geom_trans_gen(num_or_xy,
                                         func=lambda num: com.point_to_pixel(num, ppi=self.ppi),
                                         verbose=verbose)
        
        return kw.extract(kwargs=kwargs, keys=keys, trans=trans,
                          func=geom_trans_, verbose=verbose)
        
    
    def line(self, depth=0, **kwargs): 
        """線分を描く．描画命令のpillowのdrawオブジェクトのnative演算による実装．

        Args: 
            kwargs (dict): 次のキーワードパラメータを含む辞書．

                * xy : list (with is_point_seq(xy)==True)
                  a list of points [(x0,y0), (x1,y1)] in grid coordinate
                * fill : str 
                  a string represeting a color
                * width : number 
                  a number in pt
                * joint : str 
                  either 'curve' or None
                * verbose (bool): ログ出力のフラグ．

        Returns: 
        	なし
        """
        xy = kw.get(kwargs, key='xy', required=True)
        com.ensure(vec.is_rect(xy), f'xy={xy} must be a point list!')        
        if ('verbose' in kwargs) and (kwargs['verbose']):
            self.repo(f".line@@: kwargs={ kw.reduce(kwargs) }")

        #引数抽出: xyとwidthをスケールする
        kwargs1 = self.extract_with_trans_px(kwargs, trans=['xy', 'width'], keys=['fill', 'joint'])
        kwargs_round_px(kwargs1, ['xy', 'width'])
            
        ## 線分を描画する
        if 'fill' in kwargs1: 
            self.drawer.line(**kwargs1)

        ##ラベルを描画する
        if kw.contains(kwargs, key='label'): 
            pass #ダミー
        return

    #======
    # 長方形
    #======
    # notes: PIL.rectangleでは，outline指定の際，枠線は色のみ指定可能で，先幅は指定できない．そのため，fillが空でない時，塗りつぶし長方形をPIL.rectangleで描画し，outlineが空でない時，widthに指定の線幅で，枠線長方形をPIL.lineで4辺を描画するように実装した

    #辺の枠線を一つ描画する
    def draw_outline_edge(self, depth=0, **kwargs):
        """関数rectangle_outlinedの補助関数．
        """
        #kwargs: xy=None, side=None, width=None, outline_kind=None, verbose=False, 
        if DEBUG_OPS and kw.contains(kwargs, key='verbose'):
            self.repo(f".draw_outline_edge@@: enter: kwargs={ kw.extract(kwargs, keys=['xy'], reduced=True) }")
        xy = kw.get(kwargs, key='xy', required=True)
        
        side = kw.get(kwargs, key='side', required=True)
        com.ensure(vec.is_rect(xy), 'xy={xy} must be a point pair!')
        com.ensure(side in ('a', 'b', 'l', 'r'), f'no such a side={side}!')
        
        kwargs1 = kw.extract(kwargs, keys=['xy', 'side', 'width', 'verbose'])
        kwargs2 = kw.extract(kwargs, keys=['xy', 'width', 'fill'])
        
        if DEBUG_OPS and kw.contains(kwargs, key='verbose'): 
            self.repo(f'.draw_outline_edge@@: mid:   kwargs1={kwargs1}')
            
        #枠線を引く
        outline_kind = kw.get(kwargs, key='outline_kind')
        if outline_kind in ('r', 'rect', 'rectangle'):
            kwargs2['xy'] = px.xy_edge_in_rectangle(**kwargs1)            
            self.drawer.rectangle(**kwargs2)
        elif outline_kind in ('l', 'line', None):
            kwargs2['xy'], kwargs2['width'] = px.xy_edge_in_line(**kwargs1)
            self.drawer.line(**kwargs2)
        else:
            com.panic(f'no such an outline_kind={ outline_kind }!')
            
    #角の飾りの一つを描画する
    def draw_corner_end(self, **kwargs_px):
        """矩形の角の飾りの一つを描画する．補助関数．

        Args: 
            kwargs (dict): 次のキーワードパラメータを含む辞書．        
        * xy (rect): 矩形
        * anchor (str): アンカー文字列
        * width (number): 線幅
        * corner (str): 隅の色を表す文字列
        * corner_kind (str): 隅の形を表す次の文字列 in ('square', 'box', 'round', 'circle')
        * verbose (bool): ログ出力のフラグ. 

        Returns: 
        	なし

        """
        #kwargs_px: xy=None, side=None, width=None, outline_kind=None, verbose=False, 
        if DEBUG_OPS and kw.contains(kwargs_px, key='verbose'): 
            self.repo(f'@pilimage.draw_corner_end: kwargs_px={kwargs_px}')

        #引数を選択する
        xy = kw.get(kwargs_px, key='xy', required=True)
        anchor = kw.get(kwargs_px, key='anchor', required=True)
        width = kw.get(kwargs_px, key='width', required=True)
        verbose = kw.get(kwargs_px, key='verbose')
        kwargs1 = kw.extract(kwargs_px, keys=['xy', 'width', 'fill'])
        
        #端点の正方形の領域を計算してxyにセットする
        kwargs1['xy'] = px.xy_end_box(xy=xy, anchor=anchor, width=width,
                                      verbose=verbose)
        if kw.contains(kwargs_px, 'corner'): 
            kwargs1['fill'] = kw.get(kwargs_px, key='corner')
        
        #端点のタイプごとに基盤系関数で描画する
        if kw.get(kwargs_px, key='corner_kind') in ('square', 'box', None):
            self.drawer.rectangle(**kwargs1)
        elif corner_kind == ('round', 'circle'):
            self.drawer.ellipse(**kwargs1)
        else:
            com.panic(f'no such corner_kind={ corner_kind }!')

        return 
            
    # 矩形を描く
    def rectangle(self, depth=0, **kwargs): 
        """矩形を描く．描画命令のpillowのdrawオブジェクトのnative演算による実装．

        Args: 
            kwargs (dict): 次のキーワードパラメータを含む辞書．

                * xy : list (with is_point_seq(xy)==True)
                  a list of points [(x0,y0), (x1,y1)] in grid coordinate
                * fill : str 
                  a string represeting a color
                * width : number 
                  a number in pt
                * outline : str 
                  a string represeting a color
                * corner_kind : 'square' or 'round'
                  a string specifying the corner type (not in PIL)
        	* verbose (bool): ログ出力のフラグ. 

        Returns: 
        	なし
        """
        if kw.contains(kwargs, key='verbose'): 
            self.repo(f'.rectangle@@: kwargs={kwargs}')

        #目標領域xy
        xy_ = kw.get(kwargs, key='xy', required=True)
        com.ensure(vec.is_rect(xy_), f'xy={xy_} must be a point list!')

        #引数抽出: ptからpxへの変換を行う
        kwargs_px = self.extract_with_trans_px(kwargs, trans=['xy', 'width'], keys=None)
        kwargs_px = kwargs_round_px(kwargs_px, keys=['xy', 'width'])
        kwargs_px['xy'] = px.xy_adjust_borders(vec.round_px(kwargs_px['xy']), xy_strict=kw.get(kwargs, key='xy_strict'))        

        #塗りつぶされた長方形を描く
        kwargs1 = kw.extract(kwargs_px, keys=['xy', 'width', 'fill']) 
        if kw.contains(kwargs1, key='fill'): 
            self.drawer.rectangle(**kwargs1)
        
        # la --- ra
        #  |     | 
        # lb --- rb
        
        #辺を描く: 
        if kw.contains(kwargs, key='outline'):
            self.rectangle_outlined(**kwargs_px)
        
        #端点の描画：かざり
        if kw.contains(kwargs, key='corner_kind'):
            self.rectangle_corners(**kwargs_px)
        
        return


    # 矩形を描く
    # la -- a -- ra
    #  |          |
    #  l          r 
    #  |          | 
    # lb -- b -- rb 
    def rectangle_outlined(self, **kwargs_px):
        """内部が透明な周囲の4辺だけからなる矩形を描画する．

        Args: 
            kwargs_px (dict): 通常の長方形描画のキーワードパラメータに加えて，次のキーワードパラメータを含む辞書．        
        * outline (rect): 矩形の外周の色を表す文字列
        * outline_kind (str): 矩形の外周の種類

        Returns: 
        	なし

        * 引数には，rectangleに加えて，outline（色の文字列）, corner（色の文字列）, corner_kind（形状文字列）をもつ．

        Notes: 

        PIL.rectangleでは，outline指定の際，枠線は色のみ指定可能で，先幅は指定できない．そのため，fillが空でない時，塗りつぶし長方形をPIL.rectangleで描画し，outlineが空でない時，widthに指定の線幅で，枠線長方形をPIL.lineで4辺を描画するように実装した
        """
        #kwargs_pxは座標調整とpx化済み
        if kw.contains(kwargs_px, key='verbose'): 
            DEBUG_OPS and self.repo(f'@pilimage.rectangle_outlined: kwargs_px={kwargs_px}')
        
        kwargs1 = kw.extract(kwargs_px, keys=['xy', 'width', 'outline_kind', 'verbose']) 

        #線分描画のパラメータを作成する
        # kwargs_edges['xy']  = kw.get(kwargs1, key='xy', required=True)
        kwargs1['fill'] = kw.get(kwargs_px, key='outline')
        if kw.contains(kwargs1, 'width'): 
            kwargs1['width']  = int(kw.get(kwargs1, key='width'))
        else:
            kwargs1['width']  = com.point_to_pixel(DEFAULT_PEN_WIDTH_PT, ppi=self.ppi)
        #四辺を描画する
        self.draw_outline_edge(side='a', **kwargs1)
        self.draw_outline_edge(side='b', **kwargs1)
        self.draw_outline_edge(side='l', **kwargs1)
        self.draw_outline_edge(side='r', **kwargs1)
        return 

    #端点の描画：かざり
    # la --- ra
    #  |     | 
    # lb --- rb 
    def rectangle_corners(self, **kwargs_px):
        """角の飾りがある矩形を描画する．

        Args: 
            kwargs_px (dict): 次のキーワードパラメータを含む辞書．        
        * xy (rect): 矩形
        * anchor (str): アンカー文字列
        * width (number): 線幅
        * outline (rect): 矩形の外周の色を表す文字列
        * corner (str): 隅の色を表す文字列
        * corner_kind (str): 隅の形を表す次の文字列 in ('square', 'box', 'round', 'circle')
        * verbose (bool): ログ出力のフラグ. 

        Returns: 
        	なし

        * 引数には，rectangleに加えて，outline（色の文字列）, corner（色の文字列）, corner_kind（形状文字列）をもつ．

        """
        #kwargs_pxは座標調整とpx化済み
        if kw.contains(kwargs_px, key='verbose'): 
            DEBUG_OPS and self.repo(f'@pilimage.rectangle_outlined: kwargs_px={kwargs_px}')
        
        kwargs_px['fill'] = kw.get(kwargs_px, key='outline') #名前の付け替え
        kwargs_px['fill'] = 'red'
        
        # アンカーの位置指定は次の通り
        #          la --- ra
        #           |     | 
        #          lb --- rb 
        self.draw_corner_end(anchor='la', **kwargs_px)
        self.draw_corner_end(anchor='ra', **kwargs_px)
        self.draw_corner_end(anchor='lb', **kwargs_px)
        self.draw_corner_end(anchor='rb', **kwargs_px)
        return 

        
    # 楕円を描く
    def ellipse(self, depth=0, **kwargs): 
        """円と楕円を描く．描画命令のpillowのdrawオブジェクトのnative演算による実装．

        Args: 
            kwargs (dict): 次のキーワードパラメータを含む辞書．

                * xy : list (with is_point_seq(xy)==True)
                  a list of points [(x0,y0), (x1,y1)] in grid coordinate
                * fill : str 
                  a string represeting a color

                * outline : str 
                  a string represeting a color

                * width : number 
                  a number in pt
                * align : str  
                  either 'center' or others or None 
        	* verbose (bool): ログ出力のフラグ. 

        Returns: 
        	なし
        """
        if kw.contains(kwargs, key='verbose'):
            #kwargs_ = 
            self.repo(f".ellipse@@: kwargs={ kw.extract(kwargs, keys=['xy'], reduced=True) }")
        #引数抽出
        kwargs1 = self.extract_with_trans_px(kwargs, trans=['xy', 'width'], keys=['fill', 'outline', 'align'])
        kwargs1 = kwargs_round_px(kwargs1, ['xy', 'width'])                
        kwargs1['xy'] = px.xy_adjust_borders(vec.round_px(kwargs1['xy']),
                                     xy_strict=kw.get(kwargs, key='xy_strict'))
        self.drawer.ellipse(**kwargs1)
                    
    # 円弧を描く
    def arc(self, depth=0, **kwargs): 
        """円と楕円を描く．描画命令のpillowのdrawオブジェクトのnative演算による実装．

        xy=None, start=None, end=None, fill=None, width=1, verbose=False

        Args: 

            kwargs (dict): 次のキーワードパラメータを含む辞書．

                * xy (rect): a pair of points xy = [p, q] in grid coordinate

                * start (number) : the angle of the starting point in degree (e.g. 30, 90, 180, ...). See note below. 

                * end (number): the angle of the end point in degree (e.g. 30, 90, 180, ...). See note below. 

                * fill (str): a string represeting a color

                * width (number): a number in pt

        	* verbose (bool): ログ出力のフラグ. 

        Returns: 
            なし

        * In start and end, degree 0 means the direction of 3 o'clock (that of the x-coordinate). 

        """
        if kw.contains(kwargs, key='verbose'):
            #kwargs_ = 
            self.repo(f".arc@@: kwargs={ kw.extract(kwargs, keys=['xy'], reduced=True) }")
        #引数抽出
        kwargs1 = self.extract_with_trans_px(kwargs, trans=['xy', 'width'], keys=['fill', 'start', 'end'])
        kwargs1 = kwargs_round_px(kwargs1, ['xy', 'width'])                
        self.drawer.arc(**kwargs1)

    # 太点を描く
    def dot(self, depth=0, **kwargs):
        """太点を描く．描画命令のpillowのdrawオブジェクトのnative演算による実装．

        Args: 
            kwargs (dict): 次のキーワードパラメータを含む辞書．

                * xy (point) : 太点の中心座標．a point xy=(x0,y0) in grid coordinate
                  indicating the center of a circle

                * diameter (number ): the diameter of a dot (in pt).

                * fill (str): 色を表す文字列．a string represeting a color

                * outline (str): 輪郭線の色．これが非Noneならば，輪郭線だけで書く．
                  a string represeting a color

                * width (number): 太点の直径（単位はペン幅）. the width of outline if outline is non-None

                * verbose (bool): ログ出力のフラグ．

        Returns: 
            なし
        """
        if kw.contains(kwargs, key='verbose'):
            #kwargs_ = 
            self.repo(f".dot@@: kwargs={ kw.extract(kwargs, keys=['xy'], reduced=True) }")
        #引数抽出:
        kwargs1 = self.extract_with_trans_px(kwargs, keys=['fill', 'width', 'outline'])
        #中心点と直径から配置形状xyを求める
        xy = kw.get(kwargs, key='xy', required=True)
        com.ensure((vec.is_point(xy)), f'xy={xy} must be a point!')
        diam = kw.get(kwargs, key='diameter', default=DEFAULT_DOT_WIDTH_PT) 
        kwargs1['xy'] = centered_box_shape(xy=xy, width=diam)

        if DEBUG_OPS and kw.contains(kwargs, key='verbose'): 
            self.repo(f'.dot@@: kwargs1={kwargs1}')
        #note: 自身のellipse関数で処理するので，xyとwidthはpt座標系で良い．
        self.ellipse(**kwargs1)
            
            
    # テキストを描く
    def text(self, depth=0, **kwargs): 
        """テキストを描く．描画命令のpillowのdrawオブジェクトのnative演算による実装．

        Args: 
            kwargs (dict): 次のキーワードパラメータを含む辞書．

                * xy : tuple (with is_point(xy)==True)
                  a point (x0,y0) in grid coordinate
                * text : str 
                  a text to dislay. 
                * fill : str 
                  a string represeting a color
                * size : str
                  a string representing the size of a font such as 'scriptsize', 'small', 'regular', 'large', 'huge'. See `pilfont.py`. 
                * anchor : str
                  a string A in {a,m,b}x{l,m,r} representing the location of an anchor point. 

                * verbose (bool): ログ出力のフラグ．

        Returns: 
        	なし

        Note: The anchor feature of PIL has the form of {a,m,b}x{l,m,r,t,s,d}, where 

        * horizontal axis (from left to right): 
            - l:left, m:middle, r:right

        * vertical axis (from top to bottom): 
            - a: ascender (top of a line)
            - t:top, m:middle, s:baseline, b:bottom (of a font)
            - d: descender (bottom of a line)

        The following features are same in the features of PIL with the same names: 

             spacing, align ('left', 'right')
             direction, features, language, 
             stroke_width=0, stroke_fill, 
             embedded_color (True or False),

        """
        ## フォント辞書を設定する
        if not kw.contains(kwargs, key='font'):
            if kw.contains(kwargs, key='size'): size = kwargs['size']
            else: size = 'regular'
            kwargs['font'] = self.fontbase.lookup_font_by_size(size)
        ## 引数
        if kw.contains(kwargs, key='verbose'):
            #kwargs_ = kw.extract(kwargs, keys=['xy'], reduced=True)
            self.repo(f".text@@: kwargs={ kw.extract(kwargs, keys=['xy'], reduced=True) }")
        #引数抽出
        kwargs1 = self.extract_with_trans_px(kwargs, trans=['xy'], keys=['text', 'font', 'size', 'fill', 'anchor', 'align', 'direction' ])
        self.drawer.text(**kwargs1)  ## テキストを描画する
        return 
        
    # テキストのbounding boxを返す
    def textbbox(self, depth=0, **kwargs): 
        """テキストの最小包含長方形を返す．描画命令のpillowのdrawオブジェクトのnative演算による実装．

        Args: 
            kwargs (dict): 次のキーワードパラメータを含む辞書．

                * xy : tuple (with is_point(xy)==True)
                  a point (x0,y0) in grid coordinate
                * text : str 
                  a text to dislay. 
                * size : str
                  a string representing the size of a font such as 'scriptsize', 'small', 'regular', 'large', 'huge'. See `pilfont.py`. 
                * anchor : str
                  a string A in {a,m,b}x{l,m,r} representing the location of an anchor point. 

                * verbose (bool): ログ出力のフラグ．

        Returns: 
        	rect: テキストの最小包含矩形 bbox = ((x0, y0), (x1, y1)). 

        The following features are same to the textbbox command in PIL: 

             spacing, align ('left', 'right')
             direction, features, language, 
             stroke_width=0, stroke_fill, 
             embedded_color (True or False),

        """
        if not kw.contains(kwargs, key='font'):
            if kw.contains(kwargs, key='size'): size = kwargs['size']
            else: size = 'regular'
            kwargs['font'] = self.fontbase.lookup_font_by_size(size)
        ## 引数
        if kw.contains(kwargs, key='verbose'):
            #kwargs_ = 
            self.repo(f".textbbox@@: kwargs={ kw.extract(kwargs, keys=['xy'], reduced=True) }")
        #引数抽出
        kwargs1 = self.extract_with_trans_px(kwargs, trans=['xy'], keys=['text', 'font', 'size', 'anchor', 'align', 'direction', ])
        x0, y0, x1, y1 = self.drawer.textbbox(**kwargs1)
        if kw.contains(kwargs, key='relative'): 
            bbox = ((0, 0), (x1-x0, y1-y0))
        else:
            bbox = ((x0, y0), (x1, y1)) 
        return bbox

    ##===============================
    ## 210717: ここまで．各描画演算を完成させる
    ##===============================
                    
#EOF
