# coding: utf_8
# pilfont.py 
"""Pillowライブラリのフォントのパッケージ

デフォールト値は次の通り

基盤画像系：デフォールト値

* DEFAULT_FONTFAMILY='Arial'
* DEFAULT_FONTSIZE_PT=12 （ピクセル単位）
* DEFAULT_PPI=144 （ピクセル単位）

基盤画像系：固有のパラメータ

* DEFAULT_FONT_SCALING=1.4
* DEFAULT_MIN_FONTSIZE_PX= 6 #px
* 要調整．現在は経験値．

"""
import sys
import numpy as np
import math
import common as com 
import vector as vec 
import anchor as ac 

#Pillow package
import PIL as pil
from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont

    # Parameters
    # ----------
    # 
    # Returns 
    # ----------
    # 
    # Atributes
    # ----------
    # 

#基盤画像系：デフォールト値
DEFAULT_FONTFAMILY='Arial'
DEFAULT_FONTSIZE_PT=12 #px
DEFAULT_PPI=144 #px: macbookpro13, retina, 2段大きめ:
# DEFAULT_PPI=72 #px

#基盤画像系：固有のパラメータ
# 要調整．現在は経験値．
DEFAULT_FONT_SCALING=1.4
DEFAULT_MIN_FONTSIZE_PX= 6 #px

#ヘルパー関数
def font_size_reduce(size):
    if size=='huge':
        return 'large'
    elif size=='large':
        return 'regular'
    elif size=='regular':
        return 'small'
    elif size=='small':
        return 'scriptsize'
    elif size=='scriptsize':
        return 'scriptsize'
    else:
        return 'regular'


#フォントベース
class PillowFontBase:
    """フォントベースのクラス．

    Attributes: 

        fontsize_regular_pt (int): 標準フォントのサイズ（ポイントpt単位）省略可能．指定しなければ，標準値のDEFAULT_FONTSIZE_PT=12が使われる．

        ppi (int): 解像度（pixel_per_inch）．省略可能．デフォールト値DEFAULT_PPI=144．

	fontfamily (str): フォントファミリー名の文字列．省略可能．DEFAULT_FONTFAMILY='Arial'．

        font (pil.ImageFont.truetype): PillowのTrueTypeフォントオブジェクト．外部からフォントオブジェクトを与える時のみ用いる．

    	font_scriptsize (pil.ImageFont.truetype): PillowのTrueTypeフォントオブジェクト．外部からフォントオブジェクトを与える時のみ用いる．
    	font_small (pil.ImageFont.truetype): PillowのTrueTypeフォントオブジェクト．外部からフォントオブジェクトを与える時のみ用いる．
        font_large (pil.ImageFont.truetype): PillowのTrueTypeフォントオブジェクト．外部からフォントオブジェクトを与える時のみ用いる．
	font_huge (pil.ImageFont.truetype): PillowのTrueTypeフォントオブジェクト．外部からフォントオブジェクトを与える時のみ用いる．

    """ 
    def __init__(self,
                 fontsize_regular_pt=None, #fontsize for regular in pt
                 ppi=DEFAULT_PPI, #pixel_per_inch. 
                 font=None, font_scriptsize=None, font_small=None, 
                 font_large=None, font_huge=None, fontfamily=None,
                 ):
        """フォントベースを生成する．基本的に引数は指定しなくて良い．指定する場合は，fontsize_regular_pt, ppi, fontfamily程度である．

        Attributes: 

        fontsize_regular_pt (int): 標準フォントのサイズ（ポイントpt単位）省略可能．指定しなければ，標準値のDEFAULT_FONTSIZE_PT=12が使われる．

        ppi (int): 解像度（pixel_per_inch）．省略可能．デフォールト値DEFAULT_PPI=144．

	fontfamily (str): フォントファミリー名の文字列．省略可能．DEFAULT_FONTFAMILY='Arial'．

        font (pil.ImageFont.truetype): PillowのTrueTypeフォントオブジェクト．省略可能．

    	font_scriptsize (pil.ImageFont.truetype): PillowのTrueTypeフォントオブジェクト．省略可能．
    	font_small (pil.ImageFont.truetype): PillowのTrueTypeフォントオブジェクト．省略可能．
        font_large (pil.ImageFont.truetype): PillowのTrueTypeフォントオブジェクト．省略可能．
	font_huge (pil.ImageFont.truetype): PillowのTrueTypeフォントオブジェクト．省略可能．

        """
        #フォントサイズの設定
        if not fontsize_regular_pt:
            fontsize_regular_pt = DEFAULT_FONTSIZE_PT
        self.fontsize   = com.point_to_pixel(fontsize_regular_pt, ppi=ppi)
            
        ## フォントオブジェクトの設定
        self.font_dict = {} 
        self.fontfamily = fontfamily
        self.gen_all_ttfonts(font=font, 
                             font_scriptsize=font_scriptsize, 
                             font_small=font_small, 
                             font_large=font_large, 
                             font_huge=font_huge, 
                             fontfamily=fontfamily)

    def fontsize(self): 
        """標準のフォントサイズを返す"""
        return self.fontsize

    def gen_ttfont(self, fontsize):
        if self.fontfamily==None:
            self.fontfamily = DEFAULT_FONTFAMILY                        
        return pil.ImageFont.truetype(self.fontfamily, fontsize)
            
    def gen_all_ttfonts(self, font=None, 
                        font_scriptsize=None, 
                        font_small=None, 
                        font_large=None, 
                        font_huge=None, 
                        fontfamily=None):
        # regular
        if font==None: 
            self.font = self.gen_ttfont(self.fontsize)
        else: self.font = font
        # small
        if font_small==None: 
            self.font_small = self.gen_ttfont(int(self.fontsize/DEFAULT_FONT_SCALING))
        else: self.font_small = font_small                
        # scriptsize
        if font_scriptsize==None: 
            self.font_scriptsize = self.gen_ttfont(int((self.fontsize/DEFAULT_FONT_SCALING)/DEFAULT_FONT_SCALING))
        else: self.font_scriptsize = font_small                
        
        # large
        if font_large==None:
            self.font_large = self.gen_ttfont(int(self.fontsize*DEFAULT_FONT_SCALING))
        else: self.font_large = font_large
        # huge
        if font_huge==None:
            self.font_huge = self.gen_ttfont(int(self.fontsize
                                                 *DEFAULT_FONT_SCALING
                                                 *DEFAULT_FONT_SCALING))
        else: self.font_huge = font_huge 

        #フォント辞書を設定する
        self.font_dict = {
            'regular':self.font, 
            'scriptsize':self.font_scriptsize, 
            'small':self.font_small, 
            'large':self.font_large, 
            'huge':self.font_huge
        }
        return 

    def lookup_font_by_size(self, size):
        if size in self.font_dict:
            return self.font_dict[size]
        else: 
            print(f'wanring: no such font size="{ size }"!'
                  +'instead, use default font size')
            return self.font

## EOF
