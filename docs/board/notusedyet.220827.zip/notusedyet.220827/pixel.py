#!/usr/bin/env python3
# coding: utf_8
# pilimage.py
"""
低レベルの描画システムの抽象化レイヤーのモジュール．

* ピクセル（ペイント）系描画特有の処理を行う．
* ドロー系描画ではダミー処理を行うモジュールで差し替える．
"""
import sys
import math
from argparse import ArgumentParser 
import common as com 
import vector as vec 
import anchor as ac


#長方形の境界タイプによる調整
def xy_adjust_borders(xy=None, xy_strict=False):
    """矩形や円を隙間なく描画する際に，境界の1ピクセルの重複を回避するために，ピクセル幅分だけ縮小して，包含矩形の高さと幅を，それぞれ1ピクセルだけ縮小して調整する．

    Args: 

    	xy (rect): 矩形

    	xy_strict (bool): もしTrueならば何もせず，もとの矩形を返す．Falseならば処理をする．デフォールト(False)

    * もしxy_strict=Trueならば，調整せずにxyを返す．
    * それ以外ならば，右方と下方の境界を1pxずつ差し引く．

    具体的には，矩形 xy = [p, q] = [(px,py), (qx,qy)] の右方辺と下方辺（座標値の増加方向）の座標を1ピクセル分縮小して得られる新しい矩形 xy1 = [p, q-(1,1)] = [(px,py), (qx-1,qy-1)]を返す．

    Note: 上記の調整は，閉区間の直積xy = [l..r]x[a..b]に対して，半開区間の直積xy = [l..r)x[a..b)を割り付けることに対応する．これにより，格子上に長方形を，互いに重複なく隙間なく並べることができる．
    """
    com.ensure(vec.is_rect(xy), 'xy={xy} must be a point pair!')    
    if xy_strict:
        return xy
    else:
        p, q = xy
        return [p, vec.sub(q, (1,1))]

#長方形の正規化
def normalize_xy(xy, verbose=False):
    """長方形の正規化．長方形表現を受け取り，第1点が左上，第2点が右上になるよう正規化する．

    Args: 
    	xy (rect): 矩形 xy = (p, q) = ((px,py), (qx,qy))
    	verbose (bool): ログ出力のフラグ

    Returns: 
    	xy1 = (p1, q1) 
    """
    com.ensure(vec.is_rect(xy), 'xy={xy} must be a point pair!')
    p, q = xy	#元の隅点
    p1, q1 = [0, 0], [0, 0]	#新しい隅点 mutable
    if verbose: print(f'(p, q) = {(p,q)}')
    for d in range(2):
        if verbose: print(f'd={d} {(p[d], q[d])}', end='')
        if p[d] <= q[d]: 
            p1[d], q1[d] = p[d], q[d]
            if verbose: print(f'=> {(p1[d], q1[d])}')
        else:
            q1[d], p1[d] = p[d], q[d]
            if verbose: print(f'=> {(p1[d], q1[d])}')
    return [tuple(p1), tuple(q1)]	#tuple immutableに変換


#長方形による外枠の実装
def xy_edge_in_rectangle(xy=None, side=None, width=None, verbose=False): 
    """受け取った長方形領域xyの外枠の領域xy1を返す．

    Args: 
    	xy (rect): [point, point] in px
    	side (str): str in ('l', 'r', 'a', 'b')
    	width (int): 境界の線幅 (in px, width >= 1, either odd or even)
    	verbose (bool): ログ出力のフラグ

    Returns: 

    	rect: 矩形 in px (property `xy` for PilImage.rectangle())
    """
    com.ensure(vec.is_rect(xy))
    com.ensure(side in ('a', 'b', 'l', 'r'), f'no such a side={side}!')
    xy = vec.round_px(xy)
    
    #線幅の調整： width1は「ずらし」のオフセットなので1px引いておく
    width = max(1, int(width))
    width1 = width - 1
    if verbose: print(f'xy={xy}, width={width} => width1={width1}')

    p, q = (0, 0), (0, 0)
    #辺の方向を決める
    if side=='a': #h
        dir, delta = 'h', (0, +1)
        p = ac.corner(xy=xy, anchor='la')
        q = ac.corner(xy=xy, anchor='ra')
    elif side=='b': #h
        dir, delta = 'h', (0, -1)
        p = ac.corner(xy=xy, anchor='lb')
        q = ac.corner(xy=xy, anchor='rb')
    elif side=='l': #v
        dir, delta = 'v', (+1, 0)
        p = ac.corner(xy=xy, anchor='la')
        q = ac.corner(xy=xy, anchor='lb')
    elif side=='r': #v
        dir, delta = 'v', (-1, 0)
        p = ac.corner(xy=xy, anchor='ra')
        q = ac.corner(xy=xy, anchor='rb')
    else:
        panic(f'no such direction={direction}')
    if verbose: print(f"'{side}': xy={[p, q]}", end='')
        
    q = vec.add(q, vec.scalar_mult(delta, width1))    
    xy0 = [p, q]
    if verbose: print(f"\t=> xy0={ xy0 }", end='')
        
    xy1 = normalize_xy(xy=xy0)
    if verbose: print(f"\t=> xy0={ xy1 }")
    return xy1

DEBUG_EDGE = False

# 線分による実装
def xy_edge_in_line(xy=None, side=None, width=None, verbose=False): 
    """受け取った長方形領域xyの外枠の領域xy1を返す．線幅はピクセル単位の整数に量子化する．

    Args: 
    	xy (rect): [point, point] in px
    	side (str) : 4近傍の方向を表す文字列 ('l', 'r', 'a', 'b')
    	width (int): 線幅 (in px, width >= 1, either odd or even)
    	verbose (bool): ログ出力のフラグ

    Returns: 

    	(rect, int): 

    	* 矩形　xy1 = (p, q) in px (property `xy` for PilImage.line())
    	* 線幅 width1 in px (property `width` for PilImage.line())
    """
    com.ensure(vec.is_rect(xy))
    com.ensure(side in ('a', 'b', 'l', 'r'), f'no such a side={side}!')
    xy = vec.round_px(xy)
    
    #線幅の量子化
    width1 = max(1, int(width))
    if width1 % 2 == 0: 
        width1 += 1
    mid1 = width // 2
    if DEBUG_EDGE: print(f'xy={ xy }, width={width} => width1={width1}, mid1={mid1}')
    
    p, q = (0, 0), (0, 0)
    #辺の方向を決める
    if side=='a': #h
        dir, delta = 'h', (0, +1)
        p = ac.corner(xy=xy, anchor='la')
        q = ac.corner(xy=xy, anchor='ra')
    elif side=='b': #h
        dir, delta = 'h', (0, -1)
        p = ac.corner(xy=xy, anchor='lb')
        q = ac.corner(xy=xy, anchor='rb')
    elif side=='l': #v
        dir, delta = 'v', (+1, 0)
        p = ac.corner(xy=xy, anchor='la')
        q = ac.corner(xy=xy, anchor='lb')
    elif side=='r': #v
        dir, delta = 'v', (-1, 0)
        p = ac.corner(xy=xy, anchor='ra')
        q = ac.corner(xy=xy, anchor='rb')
    else:
        panic(f'no such direction={direction}')
    if DEBUG_EDGE: print(f"'{side}': xy={[p, q]}", end='')
        
    p = vec.add(p, vec.scalar_mult(delta, mid1))    
    q = vec.add(q, vec.scalar_mult(delta, mid1))    
    xy0 = [p, q]
    if DEBUG_EDGE: print(f"\t=> xy0={ xy0 }", end='')
        
    xy1 = normalize_xy(xy=xy0)
    if DEBUG_EDGE: print(f"\t=> xy1={ xy1 }, width1={width1}")
    return xy1, width1


# 端点の正方形の描画
def xy_end_box(xy=None, anchor=None, width=None, verbose=False): 
    """受け取った長方形領域xyのアンカー頂点に内接する１辺がwidth in pxの正方形の領域xy1を返す．

    Args: 
    	xy : [point, point] in px
    	side : アンカー文字列
    	width : int (in px, width >= 1, either odd or even)
    	verbose (bool): ログ出力のフラグ

    Returns: 
    	rect: 端点を表す正方形領域 xy1 = [p, q]
    """
    com.ensure(vec.is_rect(xy))
    com.ensure(anchor in ('la', 'ra', 'lb', 'rb'), f'no such a side={anchor}!')
    xy = vec.round_px(xy)
    
    #線幅の調整： width1は「ずらし」のオフセットなので1px引いておく
    width = max(1, int(width))
    
    # width1 = width  ##exp: なぜこれでよいのかわかｒなあい
    
    width1 = width - 1 #original：正しいはずだが内側に1pxができる

    #これで，正しいはずだが，次の実験では内側に1pxができる．p=12が小さすぎるためか．
    #Canvasの実験オプションとして，ptでなく，pxで画像サイズを指定できるようにすべきかもしれない．
    #exp: make test1 => python3 btest1.py -p 12 -s 4:4 -w 1 -o rect

    p, q = (0, 0), (0, 0)
    p = ac.corner(xy=xy, anchor=anchor)
    q = p 
    #辺の方向を決める
    if anchor=='la': #h
        dir = (+1, +1)
    elif anchor=='lb': #h
        dir = (+1, -1)
    elif anchor=='ra': #v
        dir = (-1, +1)
    elif anchor=='rb': #v
        dir = (-1, -1)
    else:
        panic(f'no such anchor={anchor}')
    if DEBUG_EDGE:
        print(f"'{anchor}': xy={[p, q]} dir={dir}", end='')
        
    q = vec.add(q, vec.scalar_mult(dir, width1))    
    xy0 = [p, q]
    #if verbose: print(f"\t=> xy0={ xy0 }", end='')
        
    xy1 = normalize_xy(xy=xy0)
    if DEBUG_EDGE:
        print(f"\t=> xy0={ xy1 }")
    return xy1


##=====
## コマンドライン引数
##=====
CMD_NAME = (__file__.split('/'))[-1]

def reading_args_and_options():
    USAGE_STR = f'Usage: python3 { CMD_NAME } OPTIONS '
    ap = ArgumentParser(usage=USAGE_STR)
    ## 
    ## ppi 
    ap.add_argument('-w', '--width', type=int, default=1, 
                    help='set the width of a line')
    ## verbose 
    ap.add_argument('-v', '--verbose', action='store_true', default=False, 
                    help='show verbose messages')
    ## 
    args = ap.parse_args()
    return args, ap

##======
## メイン文
##======

if __name__ == '__main__':
    #コマンドラインの引数とオプションの読み込み
    opt, ap = reading_args_and_options()

    #parameters
    verbose=False

    # テスト
    print(f'\n#exp1: xy_edge_in_rectangle')
    la = (0,0); ra = (30,0)
    lb = (0,20); rb = (30,20)
    xy = [la, rb]
    width = opt.width 
    # print(f'xy={xy}')
    for side in ('a', 'b', 'l', 'r'): 
        xy1 = xy_edge_in_rectangle(xy=xy, side=side, width=width, verbose=True) 

    # テスト
    print(f'\n#exp1: xy_edge_in_line')
    la = (0,0); ra = (30,0)
    lb = (0,20); rb = (30,20)
    xy = [la, rb]
    width = opt.width 
    # print(f'xy={xy}')
    for side in ('a', 'b', 'l', 'r'): 
        xy1, width1 = xy_edge_in_line(xy=xy, side=side, width=width, verbose=True)

# EOF
