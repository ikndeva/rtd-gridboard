#coding: utf_8
"""
2次元幾何計算のパッケージ

幾何型は次のどれかである：

- 数値      number := int | float 

- 数値対  number_pair := (num, num)

  - 点      point := number_pair

  - 形状    shape :=  number_pair

- 点対    point_pair := [point, point]

  - 長方形領域 rect := point_pair 

- 点列:     point_list := [point, ...]

- 直和型
	- 領域      region := point | rect 
	- 幾何型    geom := number | point | rect 
"""
import sys
import math 
import common as com 
import pixel as px 



#=====
# ヘルパー関数
#=====

#型検査：数値
def is_number(x):
    """xがintまたはfloatかを判定し，真偽値を返す．

    Args: 
    	x (object) : 入力の値

    Returns: 
    	bool: 真偽値 

    """
    ty_ = type(x)
    return (ty_ is int) or (ty_ is float)

#型検査：点
def is_point(xy): 
    """点(x0,x1)かのTrue/Falseを判定し，真偽値を返す．

    Args: 
    	xy (object) : 任意のオブジェクト

    Returns: 
    	bool: 真偽値 

    	* オブジェクトxyが，2個の数値からなる長さ2のタプルならばTrueを返し，それ以外はFalseを返す．
    	* エラー対応：もしxyが対だが，数値以外のオブジェクトを要素にもつときはエラーを返す．

    """
    if type(xy) is tuple and len(xy) == 2: 
        if is_number(xy[0]) and is_number(xy[1]): 
            return True
        else:
            return False
            # com.panic(f'point must contain numbers only: {xy}')
    else:
        return False

#型検査：点リスト
def is_point_seq(xy):
    """入力オブジェクトxyが，1個以上の点からなるリスト[p0, p1, ...]かを判定し，真偽値を返す．

    Args: 
    	xy (object) : 任意のオブジェクト

    Returns: 
    	bool: 真偽値 

	* xyの要素poが点かどうかは，関数 is_point(po)で判定する．
    	* エラー対応：もしxyがリストだが，点以外のオブジェクトを要素にもつときはエラーを返す．
    """
    if not (type(xy) in (list, tuple)): 
        return False
    else: 
        if len(xy) == 0: 
            return False 
        for idx, po in enumerate(xy): 
            if not is_point(po):
                return False 
    return True

#型検査：点対
def is_point_pair(xy):
    """xyが二つ点の対 `xy=[p, q]`かを判定し，真偽値を返す．

    Args: 
    	xy (object) : 任意のオブジェクト

    Returns: 
    	bool: 真偽値 

    """
    return (is_point_seq(xy) and len(xy) >= 2)

#型検査：点対
def is_rect(xy):
    """xyが二つ点の対 `xy=[p, q]`かを判定し，真偽値を返す．

    Args: 
    	xy (object) : 任意のオブジェクト

    Returns: 
    	bool: 真偽値 

    """
    return is_point_pair(xy)

#型検査：数の対＝点．便利関数．
def is_number_pair(xy):
    """数の対＝点．便利関数．is_point(xy)のラッパー．

    Args: 
    	xy (object) : 任意のオブジェクト

    Returns: 
    	bool: 真偽値 

    """
    return is_point(xy)


#=====
# point 
#=====
def coord_rotate_by_rad(p):
    """点の座標をxとy入れ替えて返す．

    Args: 
    	p (vec2) : 点 p = (x, y)

    Returns: 
    	point: 点 q = (y, x)
    """
    return (p[1], p[0]) 
    
def coord_normal(p):
    """点の座標をそのまま返す．

    Args: 
    	p (vec2) : 点 p = (x, y)

    Returns: 
    	point: 点 p そのまま．
    """
    return (p[0], p[1])

#=====
# 二項関係
#=====
def eq(p, q):
    """2次元ベクトルの同値関係：p == q．

    Args: 
    	p (vec2) : 任意の点

    	q (vec2) : 任意の点

    Returns: 
    	bool: 真偽値 

    """
    return (p[0] == q[0]) and (p[1] == q[1])

def ne(p, q):
    """2次元ベクトル同値関係：p != q．
    Args: 
    	p (vec2) : 任意の点

    	q (vec2) : 任意の点

    Returns: 
    	bool: 真偽値 

    """
    return not eq(p, q)

def le(p, q):
    """2次元ベクトル大小関係：p <= q．

    Args: 
    	p (vec2) : 任意の点

    	q (vec2) : 任意の点

    Returns: 
    	bool: 真偽値 

    """
    return (p[0] <= q[0]) and (p[1] <= q[1])

def lt(p, q):
    """2次元ベクトル大小関係：p <= q．

    Args: 
    	p (vec2) : 任意の点

    	q (vec2) : 任意の点

    Returns: 
    	bool: 真偽値 

    """
    return le(p, q) and (not eq(q, p))

#=====
# 二項演算
#=====
def add(p, q):
    """2次元ベクトルの加算 p + q．

    Args: 
    	p (vec2) : 任意の点

    	q (vec2) : 任意の点

    Returns: 
    	point: r = (p[0]+q[0], p[1]+q[1])
    """
    return (p[0]+q[0], p[1]+q[1])

def sub(p, q):
    """2次元ベクトルの減算 p - q．

    Args: 
    	p (vec2) : 任意の点

    	q (vec2) : 任意の点

    Returns: 
    	point: r = (p[0]-q[0], p[1]-q[1])
    """
    return (p[0]-q[0], p[1]-q[1])

def coord_prod(p, q):
    """ベクトルpを，拡大ベクトルqで要素毎に乗算した結果のベクトルを返す．

    Args: 
    	p (vec2) : 任意の点

    	q (vec2) : 任意の点

    Returns: 
    	point: r = (p[0]*q[0], p[1]*q[1])
    """
    return (p[0]*q[0], p[1]*q[1])

def coord_div(p, q):
    """ベクトルpを，拡大ベクトルqで要素毎の除算した結果のベクトルを返す．
    ただし，q[0]==0 or q[1]==0ならばエラーを投げる．

    Args: 
    	p (vec2) : 任意の点

    	q (vec2) : 任意の点

    Returns: 
    	point: r = (p[0]/q[0], p[1]/q[1])
    """
    if q[0]==0 or q[1]==0:
        com.panic(f'divided by zero: q={ q }')
    return (p[0]/q[0], p[1]/q[1])

def coord_max(p, q):
    """2次元ベクトルの軸ごとの最大値．

    Args: 
    	p (vec2) : 任意の点

    	q (vec2) : 任意の点

    Returns: 
    	point: r = (max(p[0],q[0]), max(p[1],q[1]))

    """
    com.ensure(is_point(p), f'p={p} must be a point')
    com.ensure(is_point(q), f'q={q} must be a point')
    return (max(p[0],q[0]), max(p[1],q[1]))

def coord_min(p, q):
    """2次元ベクトルの軸ごとの最小値．

    Args: 
    	p (vec2) : 任意の点

    	q (vec2) : 任意の点

    Returns: 
    	point: r = (min(p[0],q[0]), min(p[1],q[1]))
    """
    com.ensure(is_point(p), f'p={p} must be a point')
    com.ensure(is_point(q), f'q={q} must be a point')
    return (min(p[0],q[0]), min(p[1],q[1]))

## 単位ベクトル
def unit_vector(p):
    """線分ベクトルpから、軸方向の単位ベクトルを求める．

    Args: 
    	p (vec2) : 任意のベクトル

    Returns: 
    	(vec2): 単位ベクトル e = scalar_div(p, l2norm(p))
    """
    return scalar_div(p, l2norm(p))

## 単位法線ベクトル
def unit_normal_vector(p):
    """線分ベクトルpから、単位法線ベクトル vec_normalを求める．

    Args: 
    	p (vec2) : 任意のベクトル

    Returns: 
    	(vec2): ベクトル p1   
    """
    return rotate_by_rad(unit_vector(p), 0.5*math.pi)
    # return rotate_by_rad(unit_vector(p), math.pi) #wrong?

#座標の整数型変換
def round(p):
    """座標の整数型変換．

    Args: 
    	p (vec2) : 任意のベクトル

    Returns: 
    	(vec2): ベクトル p1   
    """
    com.ensure(is_point(p), f'p={p} must be a point')
    return (int(p[0]), int(p[1]))

#座標の切り上げ
def coord_ceil(p):
    """座標の切り上げ変換．

    Args: 
    	p (vec2) : 任意のベクトル

    Returns: 
    	(vec2): ベクトル p1   
    """
    return (math.ceil(p[0]), math.ceil(p[1]))

#座標の切り上げ
def ceil(p):
    """座標の切り上げ変換．coord_ceil(p)のラッパー．

    Args: 
    	p (vec2) : 任意のベクトル

    Returns: 
    	(vec2): ベクトル p1   
    """
    return coord_ceil(p)

#座標の切り捨て
def coord_floor(p):
    """座標の切り下げ変換．

    Args: 
    	p (vec2) : 任意のベクトル

    Returns: 
    	(vec2): ベクトル p1   
    """
    return (math.floor(p[0]), math.floor(p[1]))

#中点
def point_mid(p, q, balance=0.5):
    """二つの点pとqの間のpからの距離比率がbalanceの内分点を返す．


    Args: 
    	p (vec2) : 任意のベクトル

    	q (vec2) : 任意のベクトル

    	balance (float): 比率を表す数値 in [0,1]

    Returns: 
    	(vec2): 内分点のベクトル r 

    	* 内分点 r は，比率0.0のとき端点pであり，0.5のときpとqの中点，1.0のとき端点qである．
    """
    com.ensure(is_point(p), f'p={p} must be a point')
    com.ensure(is_point(q), f'q={q} must be a point')
    vec_balance = (balance, balance)
    xy_mid = add(
        scale(p, sub((1,1), vec_balance)), 
        scale(q, vec_balance))
    return xy_mid

#=====
# Scalar 
#=====
def scalar_mult(p, c):
    """2次元ベクトルのスカラー乗算．

    Args: 
    	p (vec2): 任意のベクトル

    	c (float): 拡大係数の数値

    Returns: 
    	(vec2): ベクトル (p[0]*c, p[1]*c)  
    """
    return (p[0]*c, p[1]*c)

def scalar_div(p, c):
    """2次元ベクトルのスカラー除算．

    Args: 
    	p (vec2): 任意のベクトル

    	c (float): 拡大係数の正数値 c > 0

    Returns: 
    	(vec2): ベクトル (p[0]/c, p[1]/c)

    	* c == 0のときは，エラーを投げる．
    """
    if c==0:
        raise Exception('divided by zero')
    return (p[0]/c, p[1]/c)

def inner_prod(p, q):
    """二つの点pとqの内積を返す．

    Args: 
    	p (vec2) : 任意の点

    	q (vec2) : 任意の点

    Returns: 
    	point: 内積 r = p[0]*q[0] + p[1]*q[1]
    """
    return p[0]*q[0] + p[1]*q[1]

def l2norm(p):
    """ベクトル p のL2ノルム（ユークリッド距離）を返す．

    Args: 
    	p (vec2) : 任意の点

    Returns: 
    	point: r = math.sqrt(p[0]*p[0] + p[1]*p[1])
    """
    return math.sqrt(p[0]*p[0] + p[1]*p[1])

#=====
# 極座標変換: polar coordinate systems
#=====

def coord_polar(p):
    """直交座標の点 p=(x0,x1)を，極座標rl=(rad,len)に変換して返す．

    Args: 
    	p (vec2) : 任意の点

    Returns: 
    	(float, float): 点pの極座標 rad, len 
    """
    x, y = p
    len = math.sqrt(x**2+y**2) ## radius
    rad = math.atan2(y, x)   ## degree in rad
    return rad, len

def coord_cartesian(rl):
    """極座標の点 rl=(rad, len) を，直交座標p=(x,y)へ変換して返す．

    Args: 
    	rl (float, float): 点の極座標表示 rl = (rad, len)

    Returns: 
    	vec2 : 点の直交座標表示 p = (x,y)
    """
    rad, len = rl
    x = len * math.cos(rad)
    y = len * math.sin(rad)
    return x, y

def normalize_rad(rad): 
    """[0, 2pi)に角度を正規化する．

    Args: 
    	rad (float): ラジアン表示の角度 rad．絶対値の大きさは任意．

    Returns: 
    	float: 範囲[0.0, 2*math.pi]に正規化されたラジアン表示の角度 rad1
    """
    while rad < 0.0:
        rad = rad + 2*math.pi ##note
    while rad > 2*math.pi:
        rad = rad - 2*math.pi
    return rad

def rad(deg):
    """角度の度数をラジアンに変換する．

    Args: 
    	deg (float): 度数表示の角度 [0, 360)

    Returns: 
    	int: ラジアン表示の角度 rad 

    	* 返り値rad の[0,2*math.pi)度の範囲への正規化はしない．
    	
    """
    return int((deg/180)*math.pi)

def deg(rad):
    """角度のラジアンを度数に変換する．

    Args: 
    	rad (float): ラジアン表示の角度 rad 

    Returns: 
    	int: 度数表示の角度 deg 

    	* 返り値degの[0,360)度の範囲への正規化はしない．
    """
    return int((rad/math.pi)*180)

## 単位法線ベクトル
def rotate_by_rad(p, rad):
    """線分ベクトルpから、単位法線ベクトル vec_normalを求める
    rad: 反時計回りの角度（ラジアン）in math.pi=180deg
    """
    rad_org, len_org = coord_polar(p)  ## rad_tan:接線ベクトル
    rad_new = normalize_rad(rad_org + rad)
    return coord_cartesian((rad_new, len_org))

## 数の符号を返す
def sign(x):
    """数の符号を{-1, 0, +1}で返す．

    Args: 
    	x (number) : 入力の値

    Returns: 
    	int: 数の符号 sign in {-1, 0, +1}
    """
    if x == 0:
        return 0
    elif x > 0:
        return +1
    elif x < 0:
        return -1
    else:
        com.panic(f'no such case: {x}')

#=====
# 領域: 長方形 shape or 長方形領域 rect 
#
# 長方形形状 shape = p = (p0, p1)
# 長方形領域 rect = [p, q] = [(p0, p1), (q0, q1)]
#=====

#長方形形状への正規化
def normalize_shape(xy=None):
    """形状（数対）または矩形（点対）による領域指定xyを受け取り，その形状（数対）(x,y)を返す．
    関数get_rectと対になる．

    Args: 
    	xy : 点 (x,y) または矩形 (p,q) = ((px,py), (qx,qy))のいずれか

    Returns: 
	(nx, ny) (vec2): 左上角を原点に配置した矩形形状
    """
    if is_point(xy):
        shape = xy 
    elif is_rect(xy):
        shape = sub(xy[1], xy[0])
    else:
        com.panic(f'xy={xy} must be either a point or a point pair!')
    return shape 

#長方形領域への正規化
def normalize_rect(xy=None):
    """領域指定xyを正規化して，形状（数対, shape）が同じで原点に左上隅をもつ正規化された矩形（点対）を返す．
    関数get_shapeと対になる．

    Args: 
    	xy : 数対 (x,y) または矩形 (p, q) = ((px,py), (qx,qy))のいずれか

    Returns: 
	(p1, q1) = ((px1,py1), (qx1,qy1)) (rect): shapeが同じで原点に左上角をもつ矩形
    """
    if is_point(xy):
        rect = [(0,0), xy]
    elif is_rect(xy):
        rect = xy
    else:
        com.panic(f'xy={xy} must be either a point or a point pair!')
    return rect 

#長方形の和（最小包含矩形）
def rect_union(box0, box1, verbose=False):
    """長方形を表す点リストの対を受け取り，それらの最小包含長方形を表す対を返す．

    Args: 
    	box0 : 矩形 box0 = [p0, q0]

    	box1 : 矩形 box1 = [p1, q1]

    Returns: 
	rect: 矩形 box = [p, q]
"""
    if not box0:
        return box1
    elif not box1:
        box0
    else: 
        com.ensure(is_point_seq(box0), f'box0={box0} must be a point list!')
        com.ensure(is_point_seq(box1), f'box1={box1} must be a point list!')
        return [coord_min(box0[0], box1[0]),
                coord_max(box0[1], box1[1])]

def normalize_margin(margin=None, output_kind=None): 
    """与えられた不完全なマージン指定を展開し，補完されたマージン指定を返す．

    Args: 
    	margin (object) : 完全またはｓ不完全なマージン指定

    Returns: 
    	vec4 : 完全なマージン指定 margin1 = (mx0, my0, mx1, my1)

    マージン指定は，次のいずれか

    	    * mm (number):  4辺の共通マージン
    	    * (mx, my) - mx, my : number 4辺の共通マージン
    	    * (pm, qm) = ((mx0, my0), (mx1, my1)):  2つの点（共通フォーマット）
    	    * (mx0, my0, mx1, my1):  4辺のマージンの組(left, top, right, bottom)．完全なマージン指定という．
    """ 
    com.ensure(margin, 'margin={margin} must be defined!')
    mx0 = my0 = mx1 = my1 = 0.0
    if is_number(margin):
        mx0 = my0 = mx1 = my1 = margin
    elif is_point(margin):
        mx0 = my0 = margin[0]
        mx1 = my1 = margin[1]
    elif is_rect(margin):
        mx0, my0 = margin[0]
        mx1, my1 = margin[1]
    elif type(margin) in (tuple, list) and len(margin)==4: 
        mx0, my0, mx1, my1 = margin
    else:
        panic(f'no such case for margin={margin}')
    if output_kind == 'point_pair': 
        mm = ((mx0, my0), (mx1, my1))
    elif output_kind=='tuple': 
        mm = (mx0, my0, mx1, my1)
    else: 
        mm = ((mx0, my0), (mx1, my1)) #default point_pair
    return mm

#余白をとる
def make_box_margin(xy=None, margin=None, kind=None, verbose=False):
    """矩形形 xy とマージン指定 margin から，余白とった長方形を返す．

    Args: 
    	xy (rect): 矩形 xy = [p, q]

    	margin (object) : 完全またはｓ不完全なマージン指定

    Returns: 
    	rect: 調整後の矩形 xy1 = [p1, q1]

    マージン指定は，次のいずれか

    	    * mm (number):  4辺の共通マージン
    	    * (mx, my) - mx, my : number 4辺の共通マージン
    	    * (pm, qm) = ((mx0, my0), (mx1, my1)):  2つの点（共通フォーマット）
    	    * (mx0, my0, mx1, my1):  4辺のマージンの組(left, top, right, bottom)．完全なマージン指定という．
      
    """
    if verbose:
        print(f'@vector.make_box_margin: xy={xy} margin={margin} kind={kind}')
    com.ensure(is_rect(xy), f'xy={xy} must be a rect')
    #マージン指定の展開
    if margin: 
        ma, mb = normalize_margin(margin, output_kind='point_pair')
        
    #マージン調整の計算
    shape = normalize_shape(xy) #大きさをとる
    com.ensure(shape[0] >= ma[0] + mb[0],
               f'margin is too large!: shape[0]={shape[0]} < xsum = {ma[0]+ mb[0]}, where xy={xy}')
    com.ensure(shape[1] >= ma[1] + mb[1],
               f'margin is too large!: shape[1]={shape[1]} < ysum = {ma[1] + mb[1]}, where xy={xy}')
    if kind: 
        com.ensure(kind in ('inner', 'outer'), f'no such kind={kind}!')
    if kind =='outer': 
        xy1 = [sub(xy[0], ma), add(xy[1], mb)]
    else:
        xy1 = [add(xy[0], ma), sub(xy[1], mb)]
    xy1 = px.normalize_xy(xy1)
    if verbose:
        print(f'@vector.make_box_margin: xy={xy} => xy1={xy1} margin={margin}')
    return xy1

#=====
# 幾何汎用関数
#=====

#数値関数の点への準同型写像
def point_apply(p, func):
    """点の各座標に，数値変換関数funcを適用する．
    Obsolute: 関数geom_trans_gen(p, func)で置き換えること．
    """
    com.ensure(is_point(p), 'p={p} must be a point!')    
    return (func(p[0]), func(p[1]))

#数値関数の点への準同型写像
def rect_apply(rect, func):
    """長方形の各点に，点変換関数funcを適用する．
    Obsolute: 関数geom_trans_gen(p, func)で置き換えること．
    """
    com.ensure(is_rect(rect), 'rect={rect} must be a point pair!')    
    return [func(rect[0]), func(rect[1])]

#数値関数の数値と，点，点リストへの準同型写像
def geom_trans_gen(xy, func=None, verbose=False):
    """点または点リストのいずれかを点の関数func:Point->Pointで変換する．
    Args: 
    	xy (geom): 点またはは点列オブジェクト．

    	func (lambda): 点を点に変換する点変換関数 func:point->point

    Returns: 
    	object: 座標を変換後のオブジェクト

    * 点またはは点列オブジェクト以外のオブジェクト xy に対しては，エラーを投げる．
    * 関数 geom_trans_gen では，点変換関数 funcを引数にとることに注意．関数geom_trans_gen(p, func)では，数値変換関数 funcを引数にとる．

    """
    if is_point(xy): 
        return func(xy)
    elif is_point_seq(xy): 
        return [ func(p) for p in xy ] 
    else:
        com.panic(f'xy={xy} must be either a point or a point_list!')

#幾何オブジェクトの汎用変換関数(generic transform)
def ex_geom_trans_gen(xy, func=None, verbose=False):
    """数または，点（数値対），点リストのいずれかを関数funcで変換する便利関数．各種の変換関数の定義に用いる．
    
    Args: 
    	xy (geom): 任意のオブジェクト．

    	func (lambda): 数値を数値に変換する数値変換関数 func:number->nubmer

    Returns: 
    	object: 座標を変換後のオブジェクト

    * 数値，または，点，点列オブジェクト以外のオブジェクト xy に対しては，エラーを投げる．
    * 関数geom_trans_gen(p, func)では，数値変換関数 funcを引数にとることに注意．
    * 関数 geom_trans_gen では，点変換関数 funcを引数にとる．
    """
    def func_to_point_(p):
        return point_apply(p, func)
    
    if is_number(xy):
        return func(xy) 
    else:
        return geom_trans_gen(xy, func=func_to_point_, verbose=verbose)

def round_px(xy):
    """幾何オブジェクト xy の座標をピクセル単位で1以上の整数に丸める．
    """
    def func_round_number_(x):
        if x==0: return 0
        else: return max(1, int(x))
    return ex_geom_trans_gen(xy, func=func_round_number_)

def shift(xy, offset):
    """点または点列オブジェクトxyを，並行移動ベクトルoffsetで要素毎に加算して返す．

    Args: 
    	xy (geom): 点または点列オブジェクト

    	offset (vec2): 並行移動ベクトルoffset = (rx,ry)

    Returns: 
    	geom: 変換された点または点列オブジェクト

    * 点または点列オブジェクト以外のオブジェクト xy に対しては，エラーを投げる．
    """
    com.ensure(is_point(offset), 'offset={offset} must be a point!')
    return geom_trans_gen(xy, func=(lambda p: add(p, offset)),
                          verbose=verbose)

def scale(xy, ratio):
    """点または点列オブジェクトxyを，拡大ベクトルratioで要素毎に乗算して返す．

    Args: 
    	xy (geom): 点または点列オブジェクト

    	ratio (vec2): 数値 r または，拡大ベクトル (rx,ry)．数値 c のときは，等方拡大ベクトル (r, r)とみなす．

    Returns: 
    	geom: 変換された点または点列オブジェクト

"""
    if is_number(ratio): #1次元比率なら2次元の等方比率にしておく
        ratio = (ratio, ratio)
    return geom_trans_gen(xy, func=(lambda p: coord_prod(p, ratio)))
        
#=====
# grid shape 
#=====

def p_range(m):
    m = math.floor(m)
    return range(0,m+1)

def e_range(m):
    m = math.floor(m)
    return range(1,m+1)

def xy_max(shape):
    return shape

##イタレータ
def p_range_2dim(shape):
    """shapeから格子点 p = (i,j) のイタレータを返す．
    """
    for i in p_range(shape[0]): 
        for j in p_range(shape[1]):
            yield (i,j)

def e_range_2dim(shape):
    """shapeから格子点 p = (i,j) のイタレータを返す．
    """
    for i in e_range(shape[0]): 
        for j in e_range(shape[1]):
            yield (i,j)

#=====
# MISC 
#=====

## 清書
def fmt(p, ncol):
    """点pに対して，座標の小数点以下の桁数をncolとする清書文字列を返す．

    Args: 
    	p (vec2): 点オブジェクト

    	ncol (int): 指定する桁数の正整数

    Returns: 
    	str: 清書文字列 f'({p[0]:.{ncol}f},{p[1]:.{ncol}f})'
    """
    return f'({p[0]:.{ncol}f},{p[1]:.{ncol}f})'


## EOF

