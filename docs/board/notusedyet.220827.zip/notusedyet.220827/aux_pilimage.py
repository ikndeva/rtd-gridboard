"""PIL.ImageDrawオブジェクトへの転送
"""
# 矢印の頭を書く
def arrow_head(self,
               xy,
               fill='black',
               shape=(1, 3),
               arrow=None,
               width=2, 
               width_node=0.0,
               head_type=None,
               verbose=False
               ):
    """矢印の頭を書く: 
    - shape=(幅、長さ):矢印の頭の幅の半分と長さ
    - width_node: 指すノードの半径（ずらすために使う）

    Args: 
       xy (rect): 矢印の方向を表す線分 [p, q]
       fill='black' (str): 
       shape=(1, 3) (vec2): 外形
       arrow=None (str): in ('solid', 'line')
       width=2 (float): 線幅
       width_node=0.0 (float): ノード幅
       head_type=None (): 未使用
       verbose=False (bool): ログ出力のフラグ

    Returns: 
    	なし

    """
    debug_arrow = True
    kwargs={
        'xy':xy,
        'fill':fill,
        'shape':shape,
        'arrow':arrow,
        'width':width, 
        'width_node':width_node,
        'head_type':head_type,
        'verbose':verbose,         
    }
    if debug_arrow: 
        print(f'debug: calling arrow_head: {kwargs}')

    if not shape: 
        shape = DEFAULT_ARROW_SHAPE
    if not width_node:
        width_node = DEFAULT_DOT_WIDTH_PT
    shape_px = (self.penwidth_px(shape[0]), self.penwidth_px(shape[1]))
    offset_px = self.penwidth_px(0.5*width_node)
    if xy[0]==xy[1]:
        com.panic(f'line must have non-zero length: { xy }')
    unitvec = vec.unit_vector(vec.sub(xy[1], xy[0]));
    inv_unitvec = vec.rotate_by_rad(unitvec, math.pi)

    ##矢印の先端の点。ノードの半径分だけ線分の元へ引き戻している
    head = vec.add(xy[1],
                   vec.scalar_mult(vec.rotate(unitvec, math.pi),
                                   offset_px) )
    ##二等辺三角形の底辺の中点
    bot_mid = vec.add(head,
                      vec.scalar_mult(vec.rotate(unitvec, math.pi),
                                      shape_px[1]) )
    ##二等辺三角形の底辺の端点
    bot_left  = vec.add(bot_mid,
                        vec.scalar_mult(vec.rotate(unitvec, 0.5*math.pi),
                                        shape_px[0])
                        )
    ##二等辺三角形の底辺の端点
    bot_right = vec.add(bot_mid, vec.scalar_mult(vec.rotate(unitvec, (2.0-0.5)*math.pi), shape_px[0]))

    ## 二等辺三角形を描画する
    if arrow=='solid':
        ## 塗りつぶし
        if debug_arrow : print(f'@debug:arrow_head: put solid head! arrow={arrow}')
        triangle = [head, bot_left, bot_right]
        self.drawer.polygon(xy=triangle, fill=fill)
    elif arrow=='line':
        ## 斜辺の線画
        if debug_arrow : print(f'@debug:arrow_head: put line head! arrow={arrow}')
        edge_left, edge_right = [head, bot_left], [head, bot_right]
        self.drawer.line(xy=edge_left, fill=fill, width=width)
        self.drawer.line(xy=edge_right, fill=fill, width=width)
    else:
        com.panic(f'no such arrow type! {arrow}')
    return 

##===============================
## 210717: ここまで．各描画演算を完成させる
##===============================

# 線分を描く
def line_with_label_(self,
         xy=None,
         fill=None, width=None, joint=None,
         pensize=1,
         label=None, label_margin=0, fill_label='black',
         label_size='small', label_balance=0.5,
         label_anchor=None, anchor_hint=None, 
         arrow_head=None, arrow_tail=None,
         fill_arrow=None, arrow_shape=None, 
         width_node=None, 
         verbose=False): 
    """線分を描く 
        xy is a list of points in grid coordinate
        fill is a string represeting a color
        width is in pixel (px)
        joint is either 'curve' or None
        """
    # debug=True
    kwargs = {
        'xy':xy, 'fill':fill,
        'width':width, 'joint':joint, 'pensize':pensize,
        'label':label, 'label_anchor':label_anchor,
        'label_margin':label_margin, 'fill_label':fill_label,
        'verbose':verbose
    }
    if self.verbose: 
        print(f'@pilimage.line: kwargs=', kwargs)
    if not (type(xy) is list and len(xy) == 2):
        com.panic(f'xy must be a list of length two!: xy={xy}')

    pen_width_=None 
    if width: pen_width_ = max(1, int(width))
    else:     pen_width_ = self.penwidth_px(pensize)

    if fill: 
        kwargs1 = {
            'xy':xy, 'fill':fill,
            'width':pen_width_, 'joint':joint
        }
        ## 線分を描画する
        self.drawer.line(**kwargs1)

    ##ラベルを描画する
    if label:
        ## アンカー指定を設定
        (p, q) = xy
        orientation = vec.sub(q, p)
        if label_anchor:
            label_anchor_ = label_anchor
        else:
            label_anchor_ = ac.get_anchor(orientation, anchor_hint=anchor_hint)
        vec_normal = ac.anchor_select(orientation, label_anchor)

        ## ラベルの相対位置label_balanceを設定する
        if not label_balance:
            label_balance = 0.5
        xy_label = point_mid(xy=xy, ratio=label_balance)
        xy_label0 = xy_label
        xy_label = vec.add(xy_label,
                           vec.scalar_mult(vec_normal, label_margin))
        ## 矢印を書く
        #print(f'@debug: xy_label={xy_label}, xy_label0={xy_label0}')
        if vec.l2norm(vec.sub(xy_label, xy_label0)) > 10:
            self.line([xy_label0, xy_label], width=2, fill='blue',
                      arrow_head='line', arrow_shape=(0.5,1))

        kwargs_text = {
            'xy':xy_label, 'text':label, 'anchor':label_anchor_,
            'fill':fill_label, 'size':label_size, 'verbose':verbose
        } 
        self.text(**kwargs_text)

    ##矢印の頭を描画する
    if arrow_head or arrow_tail: 
        if not fill_arrow:
            fill_arrow = fill ##基本色
        if arrow_head: 
            self.arrow_head(xy, 
                            arrow=arrow_head,
                            shape=arrow_shape, 
                            fill=fill_arrow,
                            width=pen_width_, 
                            width_node=width_node,
                            verbose=False)
        if arrow_tail:
            inv_xy = (xy[1], xy[0])
            self.arrow_head(inv_xy, 
                            arrow=arrow_tail,
                            shape=arrow_shape, 
                            fill=fill_arrow,
                            width=pen_width_, 
                            width_node=width_node,
                            verbose=False)
    return

##===============================
## 210719: obsolute routines 
##===============================


# 曲線分を描く
def curved_line_sub(self, xy=None,
                    fill=None, width=1,
                    ##
                    label=None, label_margin=0, fill_label='black',
                    label_size='small', label_balance=0.5,
                    label_anchor=None, anchor_hint=None, 
                    ##
                    arrow_head=None, arrow_tail=None, 
                    fill_arrow=None, arrow_shape=None, 
                    width_node=2,
                    sign=0,
                    verbose=False,
                    **kwargs):
    """曲線分を描く

    未使用．
    """
    ##
    print(f'warning: not used kwargs={kwargs}')
    ##
    if not (type(xy) is list and len(xy) >= 4):
        com.panic(f'xy must be a pair of points: xy={xy}')
    pa, pb, pm, pt = xy  ## pa:始点，pb:終点, pm：中点，pt:曲線の頂点

    #円弧の中心 pc：先のpa, pb, pm, pt から求める
    aa = 0.5*0.5* vec.inner_prod(vec.sub(pb, pa), vec.sub(pb, pa))
    bb = vec.inner_prod(vec.sub(pt, pm), vec.sub(pt, pm))
    b = math.sqrt(bb)
    L = (aa + bb) /(2*b)
    unit_pt_to_pm = vec.unit_vector(vec.sub(pm, pt))
    # unit_pt_to_pm = vec.scale(unit_pm_to_pt, -1) ##reverse
    pc = vec.add(pt, vec.scale(unit_pt_to_pm, L))

    #包含長方形 xy
    la = vec.sub(pc, (L, L))
    rb = vec.add(pc, (L, L))
    xy_arc = [la, rb]

    #角度
    unit_pc_to_pa = vec.unit_vector(vec.sub(pa, pc))
    unit_pc_to_pb = vec.unit_vector(vec.sub(pb, pc))
    rad_pa, len_pa = vec.coord_polar(unit_pc_to_pa)
    rad_pb, len_pb = vec.coord_polar(unit_pc_to_pb)

    if not (sign==None) and sign < 0:
        rad_pa, rad_pb = rad_pb, rad_pa ##円弧の中心の向きが逆

    ## 頂点半径分だけ少し短い円弧
    delta_pa_to_pb = vec.scale(vec.unit_vector(vec.sub(pb, pa)), width_node)
    delta_pb_to_pa = vec.scale(delta_pa_to_pb, -1)
    pa_perturb = vec.add(pa, delta_pa_to_pb) ##頂点の半径分引き戻す
    pb_perturb = vec.add(pb, delta_pb_to_pa) ##頂点の半径分引き戻す
    unit_pc_to_pa_arrow = vec.unit_vector(vec.sub(pa_perturb, pc))
    unit_pc_to_pb_arrow = vec.unit_vector(vec.sub(pb_perturb, pc))
    unit_tan_head = vec.rotate(unit_pc_to_pb_arrow, 0.5*math.pi) #head
    unit_tan_tail = vec.rotate(unit_pc_to_pa_arrow, -0.5*math.pi)#tail

    ## 描画：デバッグ
    if verbose: 
        self.dot(xy=pa, fill='blue', width=width, verbose=False)    
        self.dot(xy=pb, fill='blue', width=width, verbose=False)    
        self.dot(xy=pm, fill='green', width=width, verbose=False)    
        self.dot(xy=pt, fill='blue', width=width, verbose=False)
        self.dot(xy=pc, fill='crimson', width=width, verbose=False)

    ## 円弧を描く
    self.arc(xy=xy_arc, start=vec.deg(rad_pa), end=vec.deg(rad_pb),
             fill=fill, width=width, verbose=False)

    ##矢印の頭を描画する
    if arrow_head or arrow_tail: 
        if not fill_arrow:
            fill_arrow = fill ##基本色

        kwargs_arrow =  {
            # 'arrow':arrow_head,
            'shape':arrow_shape, 
            'fill':fill_arrow,
            'width_node':width_node,
            'verbose':False
        }
        if width:
            kwargs_arrow['width'] = RATIO_ARROW_HEAD_WIDTH * int(width)
        if arrow_head:
            self.arrow_head(xy=[vec.sub(pb, unit_tan_head), pb],
                            arrow=arrow_head, 
                            **kwargs_arrow)
        if arrow_tail:
            self.arrow_head(xy=[vec.sub(pa, unit_tan_tail), pa],
                            arrow=arrow_tail, 
                            **kwargs_arrow)
    ##ラベルを描画する
    if label:
        ## ラベルの位置: 簡易版．アンカーと，label_margin，線分を無視．
        xy_label = pt ##円弧の頂点位置
        xy_label0 = xy_label

        #デバッグ．マージンベクトルを表示する
        if verbose: 
            if vec.l2norm(vec.sub(xy_label, xy_label0)) > 10:
                self.line([xy_label0, xy_label], width=2, fill='blue',
                          arrow_head='line', arrow_shape=(0.5,1))

        kwargs_text = {
            'xy':xy_label, 'text':label, 'anchor':label_anchor,
            'fill':fill_label, 'size':label_size, 'verbose':verbose
        } 
        self.text(**kwargs_text)

    return 


