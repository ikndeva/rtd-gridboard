#/usr/bin/env bash

# ROMAN
col_red="0;31"
col_green="0;32"
col_yellow="0;33"
col_purple="0;34"
col_pink="0;35"
col_blue="0;36"
col_grey="0;37"
col_white="0;38"
# bold
bol_red="1;31"
bol_green="1;32"
bol_yellow="1;33"
bol_purple="1;34"
bol_pink="1;35"
bol_blue="1;36"
bol_grey="1;37"
bol_white="1;38"

## 
GREP_COLOR="$col_pink" grep -E --color=always '$|$' \
    | GREP_COLOR="$col_blue" grep -E --color=always '$|\[[^]]*\]|File.*|$' \
    | GREP_COLOR="$col_green" grep -E --color=always '$|{.*}|$' \
    | GREP_COLOR="$bol_yellow" grep -E --color=always '$|^Traceback.*$|^.*debug|^@panic!:?|^Exception: panic!|arrange|draw|$' \
    | GREP_COLOR="$col_white" grep -E --color=always '$|$' \
    | GREP_COLOR="$bol_red" grep -E --color=always '$|@[a-zA-Z_.]*:?|$' \
    | cat 

#unbuffer -p grep -E --color=auto '$|\^|^@|シンボル|場所|クラス|エ ラー|@error|Boolean|Integer|Double|String|Bottom|Step|StepRule|$'

#EOF

